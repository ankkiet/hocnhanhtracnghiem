// Tự động nhận diện môi trường (Localhost vs Production)
let API_BASE_URL = "https://inland-marylin-hocnhanhtn-c3471a95.koyeb.app"; // QUAN TRỌNG: Link Koyeb thật của bạn
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1' || window.location.protocol === 'file:') {
    API_BASE_URL = "http://127.0.0.1:8000";
} else if (window.location.hostname.startsWith('192.168.')) {
    API_BASE_URL = `http://${window.location.hostname}:8000`; // Hỗ trợ test qua mạng LAN (Live Server IP)
}

// Tự động gửi tín hiệu đánh thức máy chủ Backend ngay khi mở trang (Chống Sleep / Cold Start)
fetch(`${API_BASE_URL}/api/health`, { method: 'GET', cache: 'no-store' }).catch(() => {});

let currentData = [];
let serverData = []; // Lưu trữ dữ liệu gốc mới nhất từ Server để phục hồi khi làm lại
let currentMode = 'edit';
let currentQuestionIndex = 0;
let practiceScore = 0;
let practiceAnswered = false;
let timerInterval;
let currentTimeLimit = 0;
let editingQuizId = null;

let studentName = "";
let startTime = 0;
let isStudentMode = false;
let currentDataMode = 'practice';
let isShuffleEnabled = false;
let quizProgress = {};
let adminApiKeys = [];
let isShowingTrash = false;

// Khởi tạo bộ nhớ tạm để thu gọn mã Base64 ảnh trong Code Editor
let globalEditorImageStorage = {};
let globalEditorImageCounter = 0;

// Lưu trữ danh sách gợi ý sửa lỗi của AI gắn với từng câu hỏi
window.activeAIFeedbacks = {};

let authToken = localStorage.getItem('auth_token');
let authRole = localStorage.getItem('auth_role');
let authName = localStorage.getItem('auth_name');

// Sinh ID ngẫu nhiên cho phiên làm việc để phục vụ Giám sát thi
let clientSessionId = sessionStorage.getItem('client_session_id');
if (!clientSessionId) {
    clientSessionId = 'sess_' + Math.random().toString(36).substr(2, 9);
    sessionStorage.setItem('client_session_id', clientSessionId);
}
let heartbeatInterval;

// Biến quản lý xác thực Google Sign-In
let googleClientId = '';
let googleTokenClient = null;

function renderMath() {
    if (currentMode === 'edit') return; // Không render MathJax trong chế độ sửa để bảo toàn mã LaTeX
    if (window.MathJax && typeof window.MathJax.typesetPromise === 'function') {
        MathJax.typesetPromise().catch((err) => console.log('MathJax error:', err));
    } else {
        // Chờ MathJax tải xong (do thẻ script là async)
        setTimeout(renderMath, 500);
    }
}

window.onload = async function() {
    initGoogleAuth();
    checkAuthState();
};


function escapeHtml(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;')
              .replace(/"/g, '&quot;')
              .replace(/'/g, '&#039;');
}

function initGoogleAuth() {
    console.log("Firebase Authentication initialized.");
}

async function triggerGoogleSignIn() {
    try {
        if (!window.signInWithPopup || !window.firebaseAuth || !window.googleProvider) {
            alert("Đang nạp thư viện Firebase Google Sign-In... Vui lòng thử lại sau giây lát.");
            return;
        }

        // Mở popup đăng nhập bằng tài khoản Google chính chủ Firebase
        const result = await window.signInWithPopup(window.firebaseAuth, window.googleProvider);
        const user = result.user;
        const idToken = await user.getIdToken();

        // Gửi token về Backend để đồng bộ tài khoản và tạo JWT Token
        const res = await fetch(`${API_BASE_URL}/api/auth/google`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ credential: idToken })
        });

        const data = await res.json();
        if (res.ok && data.status === 'success') {
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('auth_role', data.role);
            localStorage.setItem('auth_name', data.full_name);
            authToken = data.token;
            authRole = data.role;
            authName = data.full_name;
            checkAuthState();

            const roleDesc = data.role === 'admin' ? '🛡️ Quản trị viên (Admin)' : (data.role === 'teacher' ? '👨‍🏫 Giáo viên' : '👨‍🎓 Học sinh');
            alert(`🎉 Đăng nhập thành công với Google!\nXin chào: ${data.full_name}\nVai trò: ${roleDesc}`);
        } else {
            alert("Lỗi máy chủ xác thực: " + (data.detail || "Không thể xác minh tài khoản."));
        }
    } catch (err) {
        console.error("Firebase Google Sign-In Error:", err);
        if (err.code === 'auth/popup-closed-by-user') {
            return; // Người dùng chủ động đóng popup
        }
        if (err.code === 'auth/unauthorized-domain') {
            alert("⚠️ Tên miền hiện tại (" + window.location.hostname + ") chưa được cấp phép trong Firebase Auth.\n\n👉 Cách cấp phép:\n1. Mở Firebase Console > Authentication > Settings > Authorized domains\n2. Nhấn 'Add domain' và thêm: " + window.location.hostname);
            return;
        }
        alert("Lỗi đăng nhập Google: " + (err.message || err));
    }
}
window.triggerGoogleSignIn = triggerGoogleSignIn;

function checkAuthState() {
    const authBox = document.getElementById('authContainer');
    if (!authToken) {
        if (authBox) {
            authBox.classList.remove('hidden');
            authBox.style.setProperty('display', 'flex', 'important');
            authBox.style.justifyContent = 'center';
            authBox.style.alignItems = 'center';
            authBox.style.minHeight = '85vh';
            authBox.style.width = '100%';
        }
        document.getElementById('mainAppContainer').style.display = 'none';
        document.getElementById('adminContainer').style.display = 'none';
        
        // Mặc định luôn chỉ hiển thị Form Đăng nhập, ẩn triệt để Form Đăng ký
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');
        if (loginForm) loginForm.style.setProperty('display', 'flex', 'important');
        if (registerForm) registerForm.style.setProperty('display', 'none', 'important');
    } else if (authRole === 'admin') {
        if (authBox) {
            authBox.classList.add('hidden');
            authBox.style.setProperty('display', 'none', 'important');
        }
        document.getElementById('mainAppContainer').style.display = 'none';
        document.getElementById('adminContainer').style.display = 'block';
        loadAdminUsers();
        loadAdminSettings();
    } else {
        if (authBox) {
            authBox.classList.add('hidden');
            authBox.style.setProperty('display', 'none', 'important');
        }
        document.getElementById('adminContainer').style.display = 'none';
        document.getElementById('mainAppContainer').style.display = 'block';
        
        document.getElementById('currentUserDisplay').innerText = `👤 Xin chào, ${authName} (${authRole === 'teacher' ? 'Giáo viên' : 'Học sinh'})`;
        document.getElementById('studentNameInput').value = authName; // Tự động điền tên học sinh
        
        if (authRole === 'student') {
            document.getElementById('creationHub').style.display = 'none';
            document.getElementById('studentDashboard').style.display = 'block';
        } else if (authRole === 'teacher') {
            document.getElementById('teacherDashboard').style.display = 'block';
            loadTeacherQuizzes();
        }
        initApp();
    }
}

function toggleAuth(type) {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    if (!loginForm || !registerForm) return;

    if(type === 'register') {
        loginForm.style.setProperty('display', 'none', 'important');
        registerForm.style.setProperty('display', 'flex', 'important');
    } else {
        loginForm.style.setProperty('display', 'flex', 'important');
        registerForm.style.setProperty('display', 'none', 'important');
    }
}


async function handleLogin() {
    const uInput = document.getElementById('email') || document.getElementById('loginUsername');
    const pInput = document.getElementById('password') || document.getElementById('loginPassword');
    const u = uInput ? uInput.value.trim() : '';
    const p = pInput ? pInput.value.trim() : '';
    if(!u || !p) return alert("Vui lòng nhập đầy đủ email/tên đăng nhập và mật khẩu");
    
    try {
        const res = await fetch(`${API_BASE_URL}/api/auth/login`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username: u, password: p})
        });
        const data = await res.json();
        if(res.ok && data.status === 'success') {
            localStorage.setItem('auth_token', data.token);
            localStorage.setItem('auth_role', data.role);
            localStorage.setItem('auth_name', data.full_name);
            authToken = data.token; authRole = data.role; authName = data.full_name;
            checkAuthState();
        } else { alert("Lỗi: " + data.detail); }
    } catch(e) { 
        console.error(e);
        alert(`Lỗi kết nối máy chủ! Backend đang trỏ tới: ${API_BASE_URL}\nHãy đảm bảo bạn đã chạy lệnh: uvicorn main:app --reload`); 
    }
}


async function handleRegister() {
    const u = document.getElementById('regUsername').value.trim();
    const p = document.getElementById('regPassword').value.trim();
    const fn = document.getElementById('regFullName').value.trim();
    const r = document.getElementById('regRole').value;
    if(!u || !p || !fn) return alert("Vui lòng nhập đủ thông tin");
    
    try {
        const res = await fetch(`${API_BASE_URL}/api/auth/register`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username: u, password: p, full_name: fn, role: r})
        });
        const data = await res.json();
        if(res.ok && data.status === 'success') {
            alert("Đăng ký thành công! Vui lòng chờ Quản trị viên duyệt tài khoản.");
            toggleAuth('login');
        } else { alert("Lỗi: " + data.detail); }
    } catch(e) { alert("Lỗi kết nối máy chủ"); }
}

function logout() {
    localStorage.clear();
    window.location.href = window.location.pathname; // Tải lại trang xóa query param
}

/* ========================================================
   GOOGLE SIGN-IN CLIENT LOGIC (ĐÃ CHUYỂN SANG FIREBASE AUTH)
   ======================================================== */




async function initApp() {
    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('quiz_id') || urlParams.get('id');
    if (quizId) {
        document.getElementById('creationHub').style.display = 'none';
        document.getElementById('btnEdit').style.display = 'none'; 
        document.getElementById('quiz-container').innerHTML = "<p style='text-align:center;'>Đang tải dữ liệu bài thi...</p>";
        try {
            const response = await fetch(`${API_BASE_URL}/api/get_quiz/${quizId}?teacher_token=${authToken || ''}`);
            const result = await response.json();
            if (result.status === 'success') {
                currentData = normalizeImageUrls(result.data);
                serverData = JSON.parse(JSON.stringify(currentData));
                const serverUpdatedAt = result.updated_at || 0;
                
                // --- Thiết lập Giao diện Dành riêng cho Học sinh ---
                document.querySelector('.header').style.display = 'none';
                document.getElementById('studentHeader').style.display = 'block';
                document.getElementById('studentQuizTitle').innerText = result.title;
                document.getElementById('studentQCount').innerHTML = `🏷 Số câu: ${currentData.length}` + (result.is_shuffle ? ` <span style="color: var(--success); font-size: 0.85rem; background: #d1fae5; padding: 2px 6px; border-radius: 4px; margin-left: 5px;">🔀 Đã trộn ngẫu nhiên</span>` : '');
                
                currentTimeLimit = result.time_limit || 0;
                if (currentTimeLimit > 0) {
                    document.getElementById('studentTime').innerText = `⏳ Thời gian: ${currentTimeLimit} phút`;
                }
                
                document.getElementById('modeSwitch').style.display = 'none'; // Ẩn hoàn toàn các nút công cụ
                
                isShuffleEnabled = result.is_shuffle;
                
                // KHÔI PHỤC TIẾN TRÌNH TỪ CLOUD HOẶC LOCAL STORAGE
                let loadedProgress = null;
                
                // 1. Thử lấy từ Server Cloud trước
                if (authRole === 'student' && authToken) {
                    try {
                        const pRes = await fetch(`${API_BASE_URL}/api/student/get_progress/${quizId}?student_token=${authToken}`);
                        const pData = await pRes.json();
                        if (pData.status === 'success' && pData.data) {
                            loadedProgress = pData.data;
                            localStorage.setItem(`quiz_progress_${quizId}`, JSON.stringify(loadedProgress)); // Backup xuống local
                        }
                    } catch(e) { console.log("Lỗi tải tiến trình cloud", e); }
                }
                
                // 2. Nếu Cloud không có (hoặc rớt mạng), lấy từ bộ nhớ Local
                if (!loadedProgress) {
                    const localP = localStorage.getItem(`quiz_progress_${quizId}`);
                    if (localP) { try { loadedProgress = JSON.parse(localP); } catch(e){} }
                }
                
                if (loadedProgress) {
                    try {
                        quizProgress = loadedProgress;
                        
                        if (quizProgress.quizUpdatedAt && serverUpdatedAt > 0 && quizProgress.quizUpdatedAt < serverUpdatedAt) {
                            alert("⚠️ Đề thi đã được giáo viên cập nhật nội dung/đáp án mới!\nTiến trình làm bài cũ của bạn sẽ được làm mới lại để đảm bảo tính chính xác.");
                            let oldHistory = quizProgress.history || [];
                            let sName = quizProgress.studentName || "";
                            quizProgress = { history: oldHistory, studentName: sName, quizUpdatedAt: serverUpdatedAt };
                            // Bỏ qua shuffledData cũ để hệ thống dùng currentData (data mới nhất)
                        } else {
                            if (quizProgress.studentName) document.getElementById('studentNameInput').value = quizProgress.studentName;
                            if (quizProgress.shuffledData) currentData = quizProgress.shuffledData;
                            if (!quizProgress.quizUpdatedAt) quizProgress.quizUpdatedAt = serverUpdatedAt;
                        }
                        
                        if (quizProgress.history && quizProgress.history.length > 0) {
                            const histSec = document.getElementById('historySection');
                            histSec.style.display = 'block';
                            
                            let hHtml = `<p style="color: var(--success); font-weight: 700; margin-bottom: 10px; font-size: 1.1rem;">✅ Bạn đã làm bài này ${quizProgress.history.length} lần</p>`;
                            hHtml += `<div style="max-height: 150px; overflow-y: auto; margin-bottom: 15px; text-align: left; background: #f9fafb; padding: 10px; border-radius: 8px; border: 1px solid var(--border); font-size: 0.9rem;">`;
                            quizProgress.history.slice().reverse().forEach((h, i) => { // Đảo ngược để lần mới nhất lên đầu
                                hHtml += `<div style="border-bottom: 1px solid #e5e7eb; padding: 8px 0; ${i === quizProgress.history.length - 1 ? 'border-bottom: none;' : ''}">
                                    <strong>Lần ${quizProgress.history.length - i} (${h.mode || 'Thi thử'}):</strong> <span style="color: var(--primary); font-weight: bold;">${h.score} / ${h.total}</span> câu - ⏱ ${formatTime(h.timeElapsed)} <br><span style="color: #6b7280; font-size: 0.8rem;">📅 ${h.date}</span>
                                </div>`;
                            });
                            hHtml += `</div>`;
                            
                            if (quizProgress.completed) {
                                hHtml += `<button class="btn-outline" style="font-size: 1rem; padding: 8px 15px; margin-right: 10px; background: white;" onclick="reviewHistory()">🔍 Xem lại bài làm gần nhất</button>`;
                                document.getElementById('startBtn').innerText = "🔄 Làm lại vòng mới";
                                document.getElementById('startBtn').style.backgroundColor = "var(--text-muted)";
                            } else if (Object.keys(quizProgress.answers || {}).length > 0) {
                                document.getElementById('startBtn').innerText = "🚀 Tiếp tục làm bài đang dở";
                            }
                            histSec.innerHTML = hHtml;
                        } else if (quizProgress.completed) {
                            const histSec = document.getElementById('historySection');
                            histSec.style.display = 'block';
                            histSec.innerHTML = `
                                <p style="color: var(--success); font-weight: 700; margin-bottom: 10px; font-size: 1.1rem;">✅ Hệ thống ghi nhận bạn đã làm bài này trước đó!</p>
                                <p style="margin-bottom: 15px; color: var(--text-muted);">Điểm lần trước: <b style="color: var(--primary); font-size: 1.3rem;">${quizProgress.score} / ${currentData.length}</b></p>
                                <button class="btn-outline" style="font-size: 1rem; padding: 10px 20px; margin-right: 10px; background: white;" onclick="reviewHistory()">🔍 Xem lại bài đã nộp</button>
                            `;
                            document.getElementById('startBtn').innerText = "🔄 Làm lại bài mới (Xóa dữ liệu cũ)";
                            document.getElementById('startBtn').style.backgroundColor = "var(--text-muted)";
                        } else if (Object.keys(quizProgress.answers || {}).length > 0) {
                            document.getElementById('startBtn').innerText = "🚀 Tiếp tục làm bài đang dở";
                        }
                    } catch(e){}
                }
                
                if ((!quizProgress || !quizProgress.shuffledData) && isShuffleEnabled) {
                    shuffleQuiz(true); // Trộn đề ngầm, không render lại ngay
                }
                
                isStudentMode = true;
                currentDataMode = result.mode || 'practice';
                document.getElementById('welcomeScreen').style.display = 'block'; // Hiển thị khung nhập tên
            } else { document.getElementById('quiz-container').innerHTML = "<p style='text-align:center;'>Bài thi không tồn tại hoặc đã bị xóa.</p>"; }
        } catch (e) {
            document.getElementById('quiz-container').innerHTML = `<p style='text-align:center; color: var(--danger);'><b>Không thể truy cập:</b> ${e.message || "Lỗi máy chủ"}</p>`;
            if (e.message) alert(e.message);
        }
    }
};

function sendPing() {
    if (!isStudentMode) return;
    const urlParams = new URLSearchParams(window.location.search);
    let quizId = urlParams.get('quiz_id') || urlParams.get('id');
    if (!quizId) {
        const path = window.location.pathname.replace(/^\/|\/$/g, '');
        if (path && path.length >= 5 && path.length <= 10 && !path.includes('.html')) quizId = path;
    }
    if (!quizId) return;
    
    fetch(`${API_BASE_URL}/api/monitor/ping`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            quiz_id: quizId, 
            session_id: clientSessionId, 
            student_name: studentName || 'Đang ẩn danh',
            answers_count: Object.keys(quizProgress.answers || {}).length,
            time_remaining: quizProgress.timeRemaining || 0,
            completed: quizProgress.completed || false
        })
    }).catch(e => {}); // Lỗi mạng (âm thầm bỏ qua không báo popup)
}

async function startStudentQuiz() {
    const nameInput = document.getElementById('studentNameInput').value.trim();
    studentName = nameInput;
    
    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('quiz_id') || urlParams.get('id');

    // Nếu bấm nút khi đã hoàn thành -> Có nghĩa là muốn Xóa lịch sử làm lại từ đầu
    if (quizProgress.completed) {
        const startBtn = document.getElementById('startBtn');
        const originalText = startBtn.innerText;
        startBtn.innerText = "⏳ Đang tải dữ liệu mới...";
        startBtn.disabled = true;
        
        if (quizId) {
            try {
                const response = await fetch(`${API_BASE_URL}/api/get_quiz/${quizId}?teacher_token=${authToken || ''}`);
                const result = await response.json();
                if (result.status === 'success') {
                    serverData = normalizeImageUrls(result.data);
                    isShuffleEnabled = result.is_shuffle;
                    quizProgress.quizUpdatedAt = result.updated_at || 0;
                    currentTimeLimit = result.time_limit || 0;
                    currentDataMode = result.mode || 'practice';
                }
            } catch(e) { console.error(e); }
        }

        let oldHistory = quizProgress.history || [];
        let updatedTs = quizProgress.quizUpdatedAt;
        quizProgress = { history: oldHistory, quizUpdatedAt: updatedTs };
        currentData = JSON.parse(JSON.stringify(serverData)); // KHÔI PHỤC DATA MỚI NHẤT TỪ SERVER
        if (isShuffleEnabled) shuffleQuiz(true);
        
        startBtn.innerText = originalText;
        startBtn.disabled = false;
    }
    
    quizProgress.studentName = studentName;
    if (!quizProgress.shuffledData) quizProgress.shuffledData = currentData;
    if (!quizProgress.answers) quizProgress.answers = {};
    quizProgress.completed = false;
    saveProgressToLocal();
    
    document.getElementById('welcomeScreen').style.display = 'none';
    document.getElementById('studentNameDisplay').innerText = `👤 Thí sinh: ${studentName}`;
    document.body.classList.add('minimal-mode');
    document.body.classList.remove('quiz-completed');
    if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen().catch(err => console.log("Fullscreen error:", err));
    }
    
    switchMode(currentDataMode); 
    if (currentDataMode === 'exam' && currentTimeLimit > 0) { startTimer(currentTimeLimit); }
    
    const quizContainer = document.getElementById('quiz-container');
    if (quizContainer) quizContainer.scrollTo({ top: 0, behavior: 'smooth' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    sendPing();
    clearInterval(heartbeatInterval);
    heartbeatInterval = setInterval(sendPing, 10000); // Gửi tín hiệu mỗi 10 giây
}

function restartPractice() {
    fetchLatestDataAndRestart('practice');
}

function restartExam() {
    fetchLatestDataAndRestart('exam');
}

async function fetchLatestDataAndRestart(mode) {
    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('quiz_id') || urlParams.get('id');
    
    const container = document.getElementById('quiz-container');
    if (container) container.innerHTML = "<p style='text-align:center; padding: 50px; font-weight: bold; color: var(--primary);'>🔄 Đang tải dữ liệu mới nhất từ máy chủ...</p>";
    
    if (quizId) {
        try {
            const response = await fetch(`${API_BASE_URL}/api/get_quiz/${quizId}?teacher_token=${authToken || ''}`);
            const result = await response.json();
            if (result.status === 'success') {
                serverData = normalizeImageUrls(result.data);
                isShuffleEnabled = result.is_shuffle;
                quizProgress.quizUpdatedAt = result.updated_at || 0;
                currentTimeLimit = result.time_limit || 0;
            }
        } catch(e) { console.error("Lỗi cập nhật data mới", e); }
    }
    
    let oldHistory = quizProgress.history || [];
    let updatedTs = quizProgress.quizUpdatedAt;
    quizProgress = { history: oldHistory, studentName: studentName, quizUpdatedAt: updatedTs };
    currentData = JSON.parse(JSON.stringify(serverData)); // KHÔI PHỤC DATA MỚI NHẤT TỪ SERVER
    
    if (isShuffleEnabled) {
        shuffleQuiz(true);
    }
    
    quizProgress.shuffledData = currentData;
    quizProgress.answers = {};
    quizProgress.completed = false;
    saveProgressToLocal();
    
    switchMode(mode);
    if (mode === 'exam' && currentTimeLimit > 0) { startTimer(currentTimeLimit); }
    
    if (container) container.scrollTo({ top: 0, behavior: 'smooth' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    sendPing();
}

function reviewHistory() {
    document.getElementById('welcomeScreen').style.display = 'none';
    studentName = quizProgress.studentName;
    currentMode = 'exam'; 
    document.getElementById('modeSwitch').style.display = 'none';
    document.getElementById('studentHeader').style.display = 'block';
    document.getElementById('studentNameDisplay').innerText = `👤 Thí sinh: ${studentName}`;
    document.body.classList.add('minimal-mode');
    if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen().catch(err => console.log("Fullscreen error:", err));
    }
    
    renderData(); 
    submitExam(true); // Gọi chấm điểm nhưng truyền cờ isReview = true để không gửi server
}

async function saveProgressToLocal() {
    const urlParams = new URLSearchParams(window.location.search);
    let quizId = urlParams.get('quiz_id') || urlParams.get('id');
    
    // Hỗ trợ link dạng /AAA-111 (Yêu cầu cấu hình Server Route, Frontend xử lý dự phòng)
    if (!quizId) {
        const path = window.location.pathname.replace(/^\/|\/$/g, '');
        if (path && path.length >= 5 && path.length <= 10 && !path.includes('.html')) {
            quizId = path;
        }
    }
    
    if (quizId) {
        localStorage.setItem(`quiz_progress_${quizId}`, JSON.stringify(quizProgress));
        
        // Đồng bộ ngầm lên Cloud Server nếu là học sinh đang đăng nhập
        if (authRole === 'student' && authToken) {
            fetch(`${API_BASE_URL}/api/student/save_progress`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ student_token: authToken, quiz_id: quizId, progress_data: quizProgress })
            }).catch(e => console.log("Lỗi đồng bộ cloud")); // Không dùng await để tránh giật lag UI
        }
    }
}

function joinQuizByCode() {
    let code = document.getElementById('joinQuizCode').value.trim();
    if (!code) return alert("Vui lòng nhập mã đề thi!");
    
    // Nếu học sinh lỡ dán cả đường link thì hệ thống tự bóc tách mã ra
    if (code.includes('?id=')) code = code.split('?id=')[1].split('&')[0];
    else if (code.includes('?quiz_id=')) code = code.split('?quiz_id=')[1].split('&')[0];
    else if (code.includes('/')) code = code.substring(code.lastIndexOf('/') + 1);

    window.location.href = `/?id=${code}`;
}

function toggleTrashView() {
    isShowingTrash = !isShowingTrash;
    document.getElementById('btnToggleTrash').innerText = isShowingTrash ? "🔙 Quay lại Danh sách" : "🗑️ Xem Thùng rác";
    loadTeacherQuizzes();
}

async function loadTeacherQuizzes() {
    try {
        const res = await fetch(`${API_BASE_URL}/api/teacher/quizzes?teacher_token=${authToken}`);
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            let html = `<table style="width:100%; border-collapse: collapse; text-align:left; min-width: 600px;">
                <tr style="border-bottom: 2px solid var(--border); color: var(--text-muted);">
                    <th style="padding: 12px 10px;">Tên đề thi</th>
                    <th style="padding: 12px 10px;">Chế độ</th>
                    <th style="padding: 12px 10px;">Số câu</th>
                    <th style="padding: 12px 10px;">Trạng thái</th>
                    <th style="padding: 12px 10px;">Thao tác</th>
                </tr>`;
            
            let hasItems = false;
            data.data.forEach(q => {
                if (isShowingTrash && q.status !== 'trashed') return;
                if (!isShowingTrash && q.status === 'trashed') return;
                
                hasItems = true;
                let modeStr = q.mode === 'exam' ? '<span style="display:inline-flex; align-items:center; gap:4px;"><i class="ri-file-list-3-line" style="color:var(--primary);"></i> Thi thử</span>' : '<span style="display:inline-flex; align-items:center; gap:4px;"><i class="ri-focus-3-line" style="color:#059669;"></i> Luyện tập</span>';
                let statusBadge = q.status === 'published' ? '<span style="color:var(--success); font-weight:bold; display:inline-flex; align-items:center; gap:4px;"><i class="ri-checkbox-circle-fill"></i> Đang mở</span>' : 
                                  (q.status === 'trashed' ? '<span style="color:var(--text-muted); font-weight:bold; display:inline-flex; align-items:center; gap:4px;"><i class="ri-delete-bin-line"></i> Đã xóa</span>' : '<span style="color:var(--danger); font-weight:bold; display:inline-flex; align-items:center; gap:4px;"><i class="ri-lock-fill"></i> Đã khóa</span>');
                let toggleAction = q.status === 'published' ? 'unpublished' : 'published';
                let toggleText = q.status === 'published' ? '<i class="ri-lock-line"></i> Khóa đề' : '<i class="ri-lock-unlock-line"></i> Mở lại';
                
                let actionButtons = "";
                if (isShowingTrash) {
                    actionButtons = `
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: var(--success); color: var(--success);" onclick="handleQuizAction('${q.id}', 'restore')"><i class="ri-refresh-line"></i> Khôi phục</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: var(--danger); color: var(--danger);" onclick="handleQuizAction('${q.id}', 'permanent')"><i class="ri-delete-bin-7-line"></i> Xóa vĩnh viễn</button>
                    `;
                } else {
                    actionButtons = `
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem;" onclick="copyQuizCode('${q.id}')"><i class="ri-barcode-line"></i> Mã đề</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: #0284c7; color: #0284c7; font-weight: 600;" onclick="copyQuizLink('${q.id}')"><i class="ri-file-copy-line"></i> Copy Link</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: #0284c7; color: #0284c7;" onclick="exportQuizDocx('${q.id}')"><i class="ri-file-word-2-line"></i> Tải Word</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: #0d9488; color: #0d9488;" onclick="showQuizAnalytics('${q.id}', '${(q.title || '').replace(/'/g, "\\'")}')"><i class="ri-bar-chart-grouped-line"></i> Phổ điểm</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: #8b5cf6; color: #8b5cf6;" onclick="startMonitoring('${q.id}', '${(q.title || '').replace(/'/g, "\\'")}')"><i class="ri-live-line"></i> Giám sát</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: var(--primary); color: var(--primary); font-weight: 600;" onclick="editQuiz('${q.id}')"><i class="ri-edit-line"></i> Sửa đề</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem; border-color: var(--danger); color: var(--danger);" onclick="handleQuizAction('${q.id}', 'trash')"><i class="ri-delete-bin-line"></i> Xóa</button>
                        <button class="btn-outline" style="padding: 5px 10px; font-size: 0.85rem;" onclick="toggleQuizStatus('${q.id}', '${toggleAction}')">${toggleText}</button>
                    `;
                }
                
                html += `<tr style="border-bottom: 1px solid var(--border);">
                    <td style="padding: 12px 10px; font-weight: 600; color: var(--primary);">${q.title || 'Đề thi chưa có tên'}</td>
                    <td style="padding: 12px 10px;">${modeStr}</td>
                    <td style="padding: 12px 10px;">${q.question_count}</td>
                    <td style="padding: 12px 10px;">${statusBadge}</td>
                    <td style="padding: 12px 10px;">
                        <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                            ${actionButtons}
                        </div>
                    </td>
                </tr>`;
            });
            
            if (!hasItems) {
                html += `<tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--text-muted);">${isShowingTrash ? 'Thùng rác trống.' : 'Chưa có đề thi nào.'}</td></tr>`;
            }
            
            html += `</table>`;
            document.getElementById('teacherQuizList').innerHTML = html;
        }
    } catch(e) { console.error("Lỗi tải danh sách đề", e); }
}

function copyQuizCode(quizId) {
    if (!quizId) return;
    navigator.clipboard.writeText(quizId).then(() => {
        alert("Đã copy Mã đề: " + quizId);
    }).catch(() => {
        prompt("Mã đề thi:", quizId);
    });
}

function copyQuizLink(quizId) {
    if (!quizId) return;
    const origin = (window.location.origin && window.location.origin !== "null") ? window.location.origin : "";
    let path = window.location.pathname;
    if (path.endsWith('editor.html')) path = path.replace('editor.html', 'index.html');
    const fullUrl = `${origin}${path}?id=${quizId}`;
    navigator.clipboard.writeText(fullUrl).then(() => {
        alert("Đã copy Link làm bài thi cho học sinh!");
    }).catch(() => {
        prompt("Copy Link làm bài thi:", fullUrl);
    });
}

function exportQuizDocx(quizId) {
    window.open(`${API_BASE_URL}/api/teacher/export_docx/${quizId}?teacher_token=${authToken}`, '_blank');
}

async function showQuizAnalytics(quizId, quizTitle) {
    try {
        const modal = document.getElementById('analyticsModal');
        const content = document.getElementById('analyticsContent');
        if (!modal || !content) return;
        
        modal.style.display = 'flex';
        content.innerHTML = '<div style="text-align:center; padding: 40px;"><div class="spinner" style="margin: 0 auto 15px;"></div> Đang phân tích dữ liệu bài thi...</div>';
        
        const res = await fetch(`${API_BASE_URL}/api/teacher/quiz_analytics/${quizId}?teacher_token=${authToken}`);
        const data = await res.json();
        
        if (!res.ok || data.status !== 'success') {
            content.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border); padding-bottom:12px; margin-bottom:15px;">
                    <h3 style="margin:0; color:var(--danger);">⚠️ Lỗi</h3>
                    <button class="btn-outline" style="padding:4px 10px; margin:0;" onclick="closeAnalyticsModal()">Đóng ✕</button>
                </div>
                <p style="color:var(--danger);">${data.detail || 'Không thể tải dữ liệu thống kê.'}</p>
            `;
            return;
        }
        
        if (data.total_submissions === 0) {
            content.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border); padding-bottom:12px; margin-bottom:15px;">
                    <h3 style="margin:0; color:var(--primary);">📊 Báo cáo Phổ điểm</h3>
                    <button class="btn-outline" style="padding:4px 10px; margin:0;" onclick="closeAnalyticsModal()">Đóng ✕</button>
                </div>
                <div style="text-align:center; padding:30px; color:var(--text-muted);">
                    <h4>${quizTitle}</h4>
                    <p>Chưa có học sinh nào nộp bài kiểm tra này để thống kê.</p>
                </div>
            `;
            return;
        }
        
        let bandsHtml = "";
        const bands = data.score_bands;
        const maxBandVal = Math.max(...Object.values(bands), 1);
        
        for (const [band, count] of Object.entries(bands)) {
            const pct = Math.round((count / data.total_submissions) * 100);
            const barWidth = Math.round((count / maxBandVal) * 100);
            bandsHtml += `
                <div style="margin-bottom: 10px;">
                    <div style="display:flex; justify-content:space-between; font-size:0.85rem; margin-bottom:3px;">
                        <span>Điểm <b>${band}</b></span>
                        <span><b>${count}</b> học sinh (${pct}%)</span>
                    </div>
                    <div style="background:#e2e8f0; border-radius:4px; height:12px; overflow:hidden;">
                        <div style="background:var(--primary); height:100%; width:${barWidth}%; border-radius:4px; transition:width 0.5s;"></div>
                    </div>
                </div>
            `;
        }
        
        let hardestHtml = "";
        if (data.hardest_questions && data.hardest_questions.length > 0) {
            hardestHtml = `
                <div style="margin-top:20px;">
                    <h4 style="color:#b91c1c; margin-bottom:10px;">⚠️ Các câu hỏi học sinh hay làm sai nhất:</h4>
                    <div style="display:flex; flex-direction:column; gap:8px;">
            `;
            data.hardest_questions.forEach(hq => {
                hardestHtml += `
                    <div style="background:#fef2f2; border-left:4px solid #ef4444; padding:10px 12px; border-radius:6px; font-size:0.9rem;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
                            <b>Câu ${hq.question_index}</b>
                            <span style="color:#dc2626; font-weight:bold;">Tỷ lệ làm đúng: ${hq.accuracy_rate}% (${hq.correct_count}/${data.total_submissions})</span>
                        </div>
                        <div style="color:#334155;">${hq.question_preview}</div>
                    </div>
                `;
            });
            hardestHtml += `</div></div>`;
        }
        
        content.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border); padding-bottom:12px; margin-bottom:15px;">
                <div>
                    <h3 style="margin:0; color:var(--primary);">📊 Phổ Điểm & Báo Cáo Phân Tích</h3>
                    <div style="color:var(--text-muted); font-size:0.9rem;">${quizTitle}</div>
                </div>
                <button class="btn-outline" style="padding:4px 10px; margin:0;" onclick="closeAnalyticsModal()">Đóng ✕</button>
            </div>
            
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(120px, 1fr)); gap:10px; margin-bottom:20px;">
                <div style="background:#f8fafc; padding:12px; border-radius:8px; text-align:center; border:1px solid var(--border);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Tổng bài nộp</div>
                    <div style="font-size:1.5rem; font-weight:bold; color:var(--primary);">${data.total_submissions}</div>
                </div>
                <div style="background:#f8fafc; padding:12px; border-radius:8px; text-align:center; border:1px solid var(--border);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Điểm TB</div>
                    <div style="font-size:1.5rem; font-weight:bold; color:#0284c7;">${data.average_score}</div>
                </div>
                <div style="background:#f8fafc; padding:12px; border-radius:8px; text-align:center; border:1px solid var(--border);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Điểm cao nhất</div>
                    <div style="font-size:1.5rem; font-weight:bold; color:#059669;">${data.max_score}</div>
                </div>
                <div style="background:#f8fafc; padding:12px; border-radius:8px; text-align:center; border:1px solid var(--border);">
                    <div style="font-size:0.8rem; color:var(--text-muted);">Điểm thấp nhất</div>
                    <div style="font-size:1.5rem; font-weight:bold; color:#e11d48;">${data.min_score}</div>
                </div>
            </div>
            
            <div style="background:#ffffff; border:1px solid var(--border); padding:15px; border-radius:8px; margin-bottom:15px;">
                <h4 style="margin-top:0; margin-bottom:12px; color:var(--text);">📈 Phân bố điểm số (Thang 10):</h4>
                ${bandsHtml}
            </div>
            
            ${hardestHtml}
        `;
    } catch(err) {
        console.error("Lỗi showQuizAnalytics", err);
    }
}

function closeAnalyticsModal() {
    const modal = document.getElementById('analyticsModal');
    if (modal) modal.style.display = 'none';
}

async function handleQuizAction(quizId, action) {
    let msg = "";
    if (action === 'trash') msg = "Bạn có chắc chắn muốn đưa đề thi này vào thùng rác?";
    if (action === 'permanent') msg = "Bạn có chắc chắn muốn XÓA VĨNH VIỄN đề thi này không? Hành động này không thể khôi phục!";
    if (action === 'restore') msg = "Bạn muốn khôi phục đề thi này (sẽ ở trạng thái khóa)?";
    
    if (msg && !confirm(msg)) return;
    
    try {
        const res = await fetch(`${API_BASE_URL}/api/teacher/quiz_action`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ teacher_token: authToken, quiz_id: quizId, action: action })
        });
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            if (action === 'trash') alert("Đã đưa vào thùng rác!");
            if (action === 'permanent') alert("Đã xóa vĩnh viễn!");
            if (action === 'restore') alert("Đã khôi phục thành công!");
            loadTeacherQuizzes();
        } else {
            alert("Lỗi: " + data.detail);
        }
    } catch(e) {
        alert("Lỗi kết nối máy chủ");
    }
}

function editQuiz(quizId) {
    window.location.href = `editor.html?id=${encodeURIComponent(quizId)}`;
}

function openStudioNewQuiz() {
    sessionStorage.removeItem('editor_quiz_id');
    sessionStorage.removeItem('editor_quiz_data');
    sessionStorage.removeItem('editor_quiz_title');
    sessionStorage.removeItem('editor_quiz_settings');
    window.location.href = 'editor.html';
}

async function toggleQuizStatus(quizId, newStatus) {
    try {
        const res = await fetch(`${API_BASE_URL}/api/teacher/toggle_publish`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ teacher_token: authToken, quiz_id: quizId, status: newStatus })
        });
        if (res.ok) loadTeacherQuizzes();
    } catch(e) {}
}

let monitorInterval;
let monitoringQuizId = null;

function startMonitoring(quizId, title) {
    monitoringQuizId = quizId;
    document.getElementById('teacherDashboard').style.display = 'none';
    document.getElementById('monitorDashboard').style.display = 'block';
    document.getElementById('monitorQuizTitle').innerText = "Đang giám sát: " + title;
    fetchMonitorData();
    monitorInterval = setInterval(fetchMonitorData, 5000); // Lấy dữ liệu 5s/lần
}

function stopMonitoring() {
    clearInterval(monitorInterval);
    monitoringQuizId = null;
    document.getElementById('monitorDashboard').style.display = 'none';
    document.getElementById('teacherDashboard').style.display = 'block';
}

async function fetchMonitorData() {
    if (!monitoringQuizId) return;
    try {
        const res = await fetch(`${API_BASE_URL}/api/teacher/monitor/${monitoringQuizId}?teacher_token=${authToken}`);
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            const tbody = document.getElementById('monitorTableBody');
            if (!data.data || data.data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding: 20px; color: var(--text-muted);">Chưa có học sinh nào tham gia...</td></tr>';
                document.getElementById('monitorCount').innerText = `Tổng số: 0 học sinh`;
                return;
            }
            
            data.data.sort((a, b) => {
                if (a.completed !== b.completed) return a.completed ? 1 : -1;
                if (a.is_online !== b.is_online) return a.is_online ? -1 : 1;
                return a.student_name.localeCompare(b.student_name);
            });
            
            tbody.innerHTML = data.data.map(s => {
                let status = s.completed ? '<span style="background:#d1fae5; color:#065f46; padding:4px 10px; border-radius:12px; font-size:0.85rem; font-weight:bold;">✅ Đã nộp bài</span>' : 
                             (s.is_online ? '<span style="background:#dbeafe; color:#1e40af; padding:4px 10px; border-radius:12px; font-size:0.85rem; font-weight:bold;">🟢 Đang làm</span>' : 
                             '<span style="background:#fee2e2; color:#991b1b; padding:4px 10px; border-radius:12px; font-size:0.85rem; font-weight:bold;">🔴 Mất kết nối</span>');
                let timeStr = s.time_remaining > 0 ? formatTime(s.time_remaining) : '--';
                return `<tr style="border-bottom: 1px solid var(--border);"><td style="padding: 12px 10px; font-weight: 600;">${s.student_name}</td><td style="padding: 12px 10px;">${status}</td><td style="padding: 12px 10px; font-weight:bold; color:var(--primary);">${s.answers_count} câu</td><td style="padding: 12px 10px;">${timeStr}</td></tr>`;
            }).join('');
            document.getElementById('monitorCount').innerText = `Tổng số: ${data.data.length} học sinh`;
        }
    } catch(e) {}
}

async function loadAdminSettings() {
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/get_api_key?admin_token=${authToken}`);
        const data = await res.json();
        if(res.ok && data.status === 'success') {
            adminApiKeys = data.api_keys || [];
            renderApiKeyList();
        }
    } catch(e) {}

    // Tải cấu hình Google Client ID
    try {
        const resG = await fetch(`${API_BASE_URL}/api/admin/get_google_client_id?admin_token=${authToken}`);
        const dataG = await resG.json();
        if (resG.ok && dataG.status === 'success') {
            const inputG = document.getElementById('adminGoogleClientId');
            if (inputG) {
                inputG.value = dataG.client_id || '';
            }
        }
    } catch(e) {}
}

async function saveAdminGoogleClientId() {
    const inputG = document.getElementById('adminGoogleClientId');
    if (!inputG) return;
    const cid = inputG.value.trim();
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/set_google_client_id`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ admin_token: authToken, client_id: cid })
        });
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            googleClientId = cid;
            setupGoogleSignInServices();
            alert("Đã lưu Google Client ID thành công!");
        } else {
            alert("Lỗi: " + (data.detail || "Không thể lưu Client ID"));
        }
    } catch(e) {
        alert("Lỗi kết nối máy chủ khi lưu Google Client ID");
    }
}


function renderApiKeyList() {
    const list = document.getElementById('apiKeyList');
    list.innerHTML = '';
    if (adminApiKeys.length === 0) {
        list.innerHTML = '<span style="color: var(--danger); font-size: 0.9rem;">Chưa có API Key nào được lưu.</span>';
        return;
    }
    adminApiKeys.forEach((key, index) => {
        const maskedKey = key.length > 15 ? key.substring(0, 8) + '...' + key.substring(key.length - 4) : key;
        list.innerHTML += `
            <div style="display: flex; justify-content: space-between; align-items: center; background: #f9fafb; padding: 10px 15px; border-radius: 8px; border: 1px solid var(--border);">
                <span style="font-family: monospace; font-size: 0.95rem;">${maskedKey}</span>
                <button class="btn-outline" style="padding: 4px 10px; font-size: 0.85rem; color: var(--danger); border-color: var(--danger);" onclick="removeApiKey(${index})">Xóa</button>
            </div>
        `;
    });
}

async function addApiKey() {
    const input = document.getElementById('newApiKeyInput');
    const newKey = input.value.trim();
    if (!newKey) return alert("Vui lòng nhập API Key hợp lệ!");
    if (adminApiKeys.includes(newKey)) return alert("Key này đã tồn tại trong danh sách!");
    
    adminApiKeys.push(newKey);
    input.value = '';
    await saveAdminApiKeys("Đã thêm API Key thành công!");
}

async function removeApiKey(index) {
    if (!confirm("Bạn có chắc chắn muốn xóa Key này không?")) return;
    adminApiKeys.splice(index, 1);
    await saveAdminApiKeys("Đã xóa API Key thành công!");
}

async function saveAdminApiKeys(successMsg) {
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/set_api_key`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({admin_token: authToken, api_keys: adminApiKeys})
        });
        if(res.ok) {
            renderApiKeyList();
            if (successMsg) alert(successMsg);
        }
    } catch(e) { alert("Lỗi lưu Key"); }
}

async function loadAdminUsers() {
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/users?admin_token=${authToken}`);
        const data = await res.json();
        if(res.ok && data.status === 'success') {
            let html = `<table style="width:100%; border-collapse: collapse; text-align:left;">
                <tr style="border-bottom: 2px solid var(--border); color: var(--text-muted);">
                    <th style="padding: 12px 10px;">Tài khoản</th>
                    <th style="padding: 12px 10px;">Họ tên</th>
                    <th style="padding: 12px 10px;">Vai trò</th>
                    <th style="padding: 12px 10px;">Trạng thái</th>
                    <th style="padding: 12px 10px;">Thao tác</th>
                </tr>`;
            data.data.forEach(u => {
                let roleStr = u.role === 'teacher' ? '👨‍🏫 Giáo viên' : (u.role === 'student' ? '👨‍🎓 Học sinh' : '🛡️ Admin');
                let statStr = u.status === 'approved' ? '<span style="color:var(--success); font-weight:bold;">Đã duyệt</span>' : '<span style="color:var(--danger); font-weight:bold;">Chờ duyệt</span>';
                let btn = u.status === 'pending' ? `<button class="btn-success" style="width:auto; margin:0; padding: 6px 12px; font-size:0.9rem;" onclick="approveUser('${u.id}')">Duyệt</button>` : '';
                let resetBtn = u.role !== 'admin' ? `<button class="btn-outline" style="width:auto; margin:0 0 0 8px; padding: 6px 12px; font-size:0.9rem; color: var(--primary); border-color: var(--primary);" onclick="resetUserPassword('${u.id}', '${u.username}')">Đổi MK</button>` : '';
                let delBtn = u.role !== 'admin' ? `<button class="btn-outline" style="width:auto; margin:0 0 0 8px; padding: 6px 12px; font-size:0.9rem; color: var(--danger); border-color: var(--danger);" onclick="deleteUser('${u.id}')">Xóa</button>` : '';
                html += `<tr style="border-bottom: 1px solid var(--border);">
                    <td style="padding: 12px 10px; font-weight: 600;">${u.username}</td>
                    <td style="padding: 12px 10px;">${u.full_name}</td>
                    <td style="padding: 12px 10px;">${roleStr}</td>
                    <td style="padding: 12px 10px;">${statStr}</td>
                    <td style="padding: 12px 10px;">${btn} ${resetBtn} ${delBtn}</td>
                </tr>`;
            });
            html += `</table>`;
            document.getElementById('adminUserList').innerHTML = html;
        }
    } catch(e) { alert("Lỗi tải danh sách người dùng"); }
}

async function approveUser(uid) {
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/approve`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({admin_token: authToken, user_id: uid}) });
        if(res.ok) loadAdminUsers();
    } catch(e) {}
}

async function deleteUser(uid) {
    if(!confirm("Bạn có chắc chắn muốn xóa tài khoản này?")) return;
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/delete`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({admin_token: authToken, user_id: uid}) });
        if(res.ok) loadAdminUsers();
    } catch(e) {}
}

async function resetUserPassword(uid, username) {
    const newPwd = prompt(`Nhập mật khẩu mới cho tài khoản "${username}":`);
    if (newPwd === null) return; // Nhấn Hủy
    
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/reset_password`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ admin_token: authToken, user_id: uid, new_password: newPwd.trim() })
        });
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            alert(`Đã đổi mật khẩu cho tài khoản "${username}" thành công!`);
        } else {
            alert("Lỗi: " + data.detail);
        }
    } catch(e) {
        alert("Lỗi kết nối máy chủ");
    }
}

async function changeAdminPassword() {
    const oldPwd = document.getElementById('adminOldPwd').value.trim();
    const newPwd = document.getElementById('adminNewPwd').value.trim();
    if (!oldPwd || !newPwd) return alert("Vui lòng nhập đủ mật khẩu cũ và mới!");
    
    try {
        const res = await fetch(`${API_BASE_URL}/api/admin/change_password`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ admin_token: authToken, old_password: oldPwd, new_password: newPwd })
        });
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            alert("Đổi mật khẩu thành công! Vui lòng đăng nhập lại với mật khẩu mới.");
            logout();
        } else {
            alert("Lỗi: " + data.detail);
        }
    } catch(e) {
        alert("Lỗi kết nối máy chủ");
    }
}

async function uploadFile() {
    const fileInput = document.getElementById('fileInput');
    if (!fileInput.files[0]) { alert("Vui lòng chọn file .docx hoặc .pdf!"); return; }
    
    const file = fileInput.files[0];
    const selectedFileName = file.name || "";
    let detectedTitle = selectedFileName.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ").trim();
    if (!detectedTitle) detectedTitle = "Đề thi mới";
    
    const formData = new FormData();
    formData.append("file", file);
    
    const useAI = document.getElementById('useAIToggle') ? document.getElementById('useAIToggle').checked : true;
    formData.append("use_ai", useAI);
    
    // Hiển thị trạng thái khởi tạo nhanh
    const loadingOverlay = document.getElementById('loadingOverlay');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const statusText = document.getElementById('loadingStatusText');
    
    if (loadingOverlay) {
        loadingOverlay.style.display = 'flex';
        progressBar.style.width = '35%';
        progressText.innerText = '35%';
        statusText.innerText = '⚙️ Đang gửi file lên máy chủ và mở Studio...';
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/upload`, { method: 'POST', body: formData });
        const result = await response.json();
        
        if (result.status === "processing") {
            // Chuyển hướng NGAY LẬP TỨC sang trang Studio riêng để phân tích!
            sessionStorage.removeItem('editor_quiz_id');
            sessionStorage.removeItem('editor_quiz_data');
            sessionStorage.setItem('editor_quiz_title', detectedTitle);
            sessionStorage.setItem('editor_pending_task_id', result.task_id);
            sessionStorage.setItem('editor_pending_mode', useAI ? 'ai' : 'python');

            window.location.href = `editor.html?task_id=${encodeURIComponent(result.task_id)}&title=${encodeURIComponent(detectedTitle)}&use_ai=${useAI}`;
        } else if (result.status === "success") {
            const normalizedData = normalizeImageUrls(result.data || []);
            sessionStorage.removeItem('editor_quiz_id');
            sessionStorage.removeItem('editor_pending_task_id');
            sessionStorage.setItem('editor_quiz_data', JSON.stringify(normalizedData));
            sessionStorage.setItem('editor_quiz_title', detectedTitle);
            sessionStorage.setItem('editor_quiz_settings', JSON.stringify({
                title: detectedTitle,
                mode: 'practice',
                timeLimit: 0,
                isShuffle: false
            }));
            window.location.href = 'editor.html';
        } else { 
            if (loadingOverlay) loadingOverlay.style.display = 'none';
            alert("Lỗi: " + (result.detail || "Không thể tải file lên")); 
        }
    } catch (e) { 
        if (loadingOverlay) loadingOverlay.style.display = 'none';
        alert("Lỗi kết nối máy chủ! Có thể Server đang khởi động lại (Cold Start), hãy thử lại trong ít giây."); 
    }
}

function applyUploadData(dataArray, fileName = "") {
    const normalizedData = normalizeImageUrls(dataArray || []);
    
    let detectedTitle = "Đề thi mới";
    if (fileName) {
        detectedTitle = fileName.replace(/\.[^/.]+$/, "").replace(/[_-]/g, " ").trim();
    } else if (normalizedData.length > 0 && normalizedData[0].group_title) {
        detectedTitle = normalizedData[0].group_title.replace(/<br>/gi, ' ').trim();
    }
    
    // Lưu dữ liệu vào Session Storage để trang Studio riêng tải lên
    sessionStorage.setItem('editor_quiz_data', JSON.stringify(normalizedData));
    sessionStorage.setItem('editor_quiz_title', detectedTitle);
    sessionStorage.setItem('editor_quiz_settings', JSON.stringify({
        title: detectedTitle,
        mode: 'practice',
        timeLimit: 0,
        isShuffle: false
    }));
    sessionStorage.removeItem('editor_quiz_id');

    // Chuyển hướng sang trang riêng (Studio Biên tập & Soát lỗi Đề thi)
    window.location.href = 'editor.html';
}

async function generateQuizWithAI() {
    const promptStr = document.getElementById('aiGenPrompt').value.trim();
    const count = parseInt(document.getElementById('aiGenCount').value) || 5;
    const diff = document.getElementById('aiGenDiff').value;

    if (!promptStr) return alert("Vui lòng nhập chủ đề hoặc nội dung để AI tạo đề!");
    if (count < 1 || count > 50) return alert("Số lượng câu hỏi nên từ 1 đến 50!");

    const loadingOverlay = document.getElementById('loadingOverlay');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const statusText = document.getElementById('loadingStatusText');
    
    let detectedTitle = promptStr.length > 50 ? promptStr.substring(0, 50) + "..." : promptStr;

    if (loadingOverlay) {
        loadingOverlay.style.display = 'flex';
        progressBar.style.width = '35%';
        progressText.innerText = '35%';
        statusText.innerText = '🤖 Đang khởi tạo và chuyển sang Studio...';
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/generate_quiz_ai`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ prompt: promptStr, num_questions: count, difficulty: diff })
        });
        const result = await response.json();
        
        if (response.ok && (result.status === "processing" || result.status === "success")) {
            if (result.status === "processing") {
                // Chuyển hướng NGAY LẬP TỨC sang Studio riêng để AI xử lý ngầm!
                sessionStorage.removeItem('editor_quiz_id');
                sessionStorage.removeItem('editor_quiz_data');
                sessionStorage.setItem('editor_quiz_title', detectedTitle);
                sessionStorage.setItem('editor_pending_task_id', result.task_id);
                sessionStorage.setItem('editor_pending_mode', 'ai_generate');

                window.location.href = `editor.html?task_id=${encodeURIComponent(result.task_id)}&title=${encodeURIComponent(detectedTitle)}&mode=ai_generate`;
            } else {
                const normalizedData = normalizeImageUrls(result.data || []);
                sessionStorage.removeItem('editor_quiz_id');
                sessionStorage.removeItem('editor_pending_task_id');
                sessionStorage.setItem('editor_quiz_data', JSON.stringify(normalizedData));
                sessionStorage.setItem('editor_quiz_title', detectedTitle);
                sessionStorage.setItem('editor_quiz_settings', JSON.stringify({
                    title: detectedTitle,
                    mode: 'practice',
                    timeLimit: 0,
                    isShuffle: false
                }));
                window.location.href = 'editor.html';
            }
        } else {
            if (loadingOverlay) loadingOverlay.style.display = 'none';
            alert("Lỗi AI: " + (result.detail || "Không thể tạo đề"));
        }
    } catch(e) {
        if (loadingOverlay) loadingOverlay.style.display = 'none';
        alert("Lỗi kết nối máy chủ! " + e.message);
    }
}

function backToDashboard() {
    currentData = [];
    editingQuizId = null;
    window.tempQuizSettings = null;
    document.body.classList.remove('editor-fullscreen');
    document.getElementById('quiz-container').innerHTML = '';
    document.getElementById('modeSwitch').style.display = 'none';
    document.getElementById('saveBtn').style.display = 'none';
    document.getElementById('aiCustomPrompt').style.display = 'none';
    document.getElementById('aiCustomPrompt').value = '';
    window.activeAIFeedbacks = {};
    document.getElementById('btnAICheck').style.display = 'none';
    document.getElementById('aiFeedbackBox').style.display = 'none';
    document.getElementById('backDashboardBtn').style.display = 'none';
    document.getElementById('creationHub').style.display = 'flex';
    document.getElementById('teacherDashboard').style.display = 'block';
    loadTeacherQuizzes();
}

function openPublishModal() {
    document.getElementById('publishModal').style.display = 'flex';
    if (editingQuizId && window.tempQuizSettings) {
        document.getElementById('modalQuizTitle').value = window.tempQuizSettings.title || "";
        document.getElementById('modalQuizMode').value = window.tempQuizSettings.mode || "practice";
        document.getElementById('modalQuizTime').value = window.tempQuizSettings.timeLimit || "";
        document.getElementById('modalQuizShuffle').checked = window.tempQuizSettings.isShuffle || false;
    } else {
        document.getElementById('modalQuizTitle').value = "";
        document.getElementById('modalQuizMode').value = "practice";
        document.getElementById('modalQuizTime').value = "";
        document.getElementById('modalQuizShuffle').checked = false;
    }
}

function closePublishModal() {
    document.getElementById('publishModal').style.display = 'none';
}

async function confirmPublish() {
    const title = document.getElementById('modalQuizTitle').value.trim();
    if (!title) return alert("Vui lòng nhập tên bài kiểm tra!");
    
    const mode = document.getElementById('modalQuizMode').value;
    const timeLimit = parseInt(document.getElementById('modalQuizTime').value) || 0;
    const isShuffle = document.getElementById('modalQuizShuffle').checked;
    
    const btn = document.getElementById('btnConfirmPublish');
    btn.innerText = "⏳ Đang xử lý...";
    btn.disabled = true;
    
    try {
        const payload = { 
            title: title, data: currentData, mode: mode, time_limit: timeLimit, 
            is_shuffle: isShuffle, creator_id: authToken, status: "published" 
        };
        if (editingQuizId) payload.quiz_id = editingQuizId;

        const payloadString = JSON.stringify(payload);
        const payloadSizeKB = new Blob([payloadString]).size / 1024;
        
        if (payloadSizeKB > 900) {
            alert(`⚠️ CẢNH BÁO: Đề thi của bạn có kích thước khá lớn (${Math.round(payloadSizeKB)} KB), chủ yếu do chứa nhiều hình ảnh. Việc lưu có thể bị lỗi nếu vượt quá giới hạn 1MB của cơ sở dữ liệu.\n\nKhuyên bạn nên nén/thu nhỏ kích thước ảnh trong file Word trước khi tải lên.`);
        }

        const response = await fetch(`${API_BASE_URL}/api/save_quiz`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payloadString
        });
        const result = await response.json();
        if (result.status === 'success') {
            closePublishModal();
            const shareLink = window.location.origin + window.location.pathname + "?id=" + result.quiz_id;
            prompt(`Lưu thành công!\nMã đề: ${result.quiz_id}\n\nCopy đường link gọn gàng bên dưới để gửi học sinh:`, shareLink);
            editingQuizId = result.quiz_id;
            window.tempQuizSettings = { title, mode, timeLimit, isShuffle };
            
            if (confirm("Đã xuất bản thành công! Bạn có muốn quay về màn hình Quản lý không?")) {
                backToDashboard();
            }
        }
    } catch (e) { alert("Lỗi khi kết nối với máy chủ cơ sở dữ liệu!"); }
    btn.innerText = "🚀 Lưu & Xuất bản";
    btn.disabled = false;
}

function normalizeImageUrls(data) {
    if (!data) return data;
    try {
        let jsonStr = JSON.stringify(data);
        jsonStr = jsonStr.replace(/https:\/\/pub-4ca74ee0e22a46a39755d1a829865251\.r2\.dev\//g, '/api/images/');
        return JSON.parse(jsonStr);
    } catch(e) {
        return data;
    }
}

async function checkQuizWithAI() {
    const btn = document.getElementById('btnAICheck');
    const customPrompt = document.getElementById('aiCustomPrompt').value.trim();
    btn.innerText = "⏳ Đang rà soát và thống kê toàn bộ đề thi (10-20s)...";
    btn.disabled = true;

    try {
        const res = await fetch(`${API_BASE_URL}/api/teacher/check_quiz_ai`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({teacher_token: authToken, quiz_data: currentData, custom_prompt: customPrompt})
        });
        const data = await res.json();
        if (res.ok && data.status === 'success') {
            document.getElementById('aiFeedbackBox').style.display = 'block';
            const statsContainer = document.getElementById('aiFeedbackStats');
            const contentContainer = document.getElementById('aiFeedbackContent');
            const btnApplyAll = document.getElementById('btnApplyAllAI');

            window.activeAIFeedbacks = {};

            if (Array.isArray(data.feedback) && data.feedback.length > 0) {
                data.feedback.forEach(item => {
                    window.activeAIFeedbacks[item.question_index] = item;
                });

                const stats = data.stats || {
                    total_questions: currentData.length,
                    valid_questions: currentData.length - data.feedback.length,
                    error_count: data.feedback.length,
                    accuracy_rate: Math.round(((currentData.length - data.feedback.length) / currentData.length) * 100),
                    category_counts: { knowledge: 0, answer: 0, grammar_typo: 0, format: 0 }
                };

                // Render Bảng Thống kê 4 ô chỉ số
                let statsHtml = `
                    <div class="ai-stat-grid">
                        <div class="ai-stat-card">
                            <span class="ai-stat-label">Tổng số câu hỏi</span>
                            <span class="ai-stat-val" style="color: #2563eb;">${stats.total_questions}</span>
                        </div>
                        <div class="ai-stat-card">
                            <span class="ai-stat-label">Câu đạt chuẩn 100%</span>
                            <span class="ai-stat-val" style="color: #10b981;">${stats.valid_questions}</span>
                        </div>
                        <div class="ai-stat-card">
                            <span class="ai-stat-label">Phát hiện cần sửa</span>
                            <span class="ai-stat-val" style="color: #ef4444;">${stats.error_count}</span>
                        </div>
                        <div class="ai-stat-card">
                            <span class="ai-stat-label">Tỷ lệ chính xác</span>
                            <span class="ai-stat-val" style="color: #9333ea;">${stats.accuracy_rate}%</span>
                        </div>
                    </div>

                    <div class="ai-cat-chips">
                        <span class="ai-cat-chip ai-cat-knowledge">🧠 Kiến thức: <b>${stats.category_counts?.knowledge || 0}</b></span>
                        <span class="ai-cat-chip ai-cat-answer">🎯 Đáp án: <b>${stats.category_counts?.answer || 0}</b></span>
                        <span class="ai-cat-chip ai-cat-grammar">✍️ Chính tả / Diễn đạt: <b>${stats.category_counts?.grammar_typo || 0}</b></span>
                        <span class="ai-cat-chip ai-cat-format">📐 Định dạng: <b>${stats.category_counts?.format || 0}</b></span>
                    </div>
                `;
                statsContainer.innerHTML = statsHtml;

                // Render Danh sách chỉ dẫn tận nơi từng câu bị lỗi (Navigator)
                let errorListHtml = `
                    <h4 style="margin: 15px 0 10px 0; color: #475569; font-size: 0.95rem; text-transform: uppercase;">
                        📍 Danh sách các câu phát hiện lỗi (Nhấn để cuộn tới thẻ câu):
                    </h4>
                    <div class="ai-error-list-container">
                `;

                data.feedback.forEach(item => {
                    const qIdx = item.question_index;
                    const catClass = item.category === 'knowledge' ? 'ai-cat-knowledge' :
                                     (item.category === 'answer' ? 'ai-cat-answer' :
                                     (item.category === 'grammar_typo' ? 'ai-cat-grammar' : 'ai-cat-format'));

                    errorListHtml += `
                        <div class="ai-error-item" id="ai_summary_item_${qIdx}">
                            <div style="flex: 1; min-width: 260px;">
                                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                                    <span style="font-weight: 800; color: #6b21a8; font-size: 1rem;">Câu ${qIdx + 1}</span>
                                    <span class="ai-cat-chip ${catClass}" style="padding: 2px 8px; font-size: 0.75rem;">${item.category_name || 'Lỗi'}</span>
                                </div>
                                <div style="font-size: 0.9rem; color: #475569;">${item.reason}</div>
                            </div>
                            <div style="display: flex; gap: 8px; align-items: center;">
                                <button class="btn-outline" style="padding: 6px 12px; font-size: 0.85rem; border-color: #9333ea; color: #9333ea;" onclick="jumpToQuestionCard(${qIdx})">🎯 Tới Câu ${qIdx + 1}</button>
                                <button class="btn-primary" style="padding: 6px 12px; font-size: 0.85rem; background: #9333ea;" onclick="applyAISuggestion(${qIdx})">✨ Sửa câu này</button>
                            </div>
                        </div>
                    `;
                });
                errorListHtml += `</div>`;
                contentContainer.innerHTML = errorListHtml;

                if (btnApplyAll) btnApplyAll.style.display = 'inline-block';

                // Render lại khung Xem trước để chèn các thẻ gợi ý chi tiết
                renderPreviewAll();
            } else if (Array.isArray(data.feedback) && data.feedback.length === 0) {
                statsContainer.innerHTML = `
                    <div style="text-align: center; padding: 25px 10px;">
                        <div style="font-size: 3rem; margin-bottom: 10px;">🎉</div>
                        <h3 style="margin: 0; color: #059669;">Tuyệt vời! Đề thi đạt chuẩn 100% không phát hiện lỗi!</h3>
                        <p style="margin: 6px 0 0 0; color: #64748b;">Toàn bộ câu hỏi, đáp án và định dạng đều hoàn hảo và sẵn sàng xuất bản.</p>
                    </div>
                `;
                contentContainer.innerHTML = '';
                if (btnApplyAll) btnApplyAll.style.display = 'none';
            } else {
                statsContainer.innerHTML = '';
                contentContainer.innerHTML = (typeof data.feedback === 'string') ? data.feedback.replace(/\n/g, '<br>') : 'Phản hồi không hợp lệ.';
                if (btnApplyAll) btnApplyAll.style.display = 'none';
            }

            document.getElementById('aiFeedbackBox').scrollIntoView({behavior: 'smooth', block: 'start'});
        } else {
            alert("Lỗi AI: " + (data.detail || "Không thể phân tích đề thi"));
        }
    } catch(e) {
        alert("Lỗi kết nối tới máy chủ khi gọi AI.");
    }
    btn.innerText = "🤖 AI Kiểm tra lỗi & Phân tích Đề thi";
    btn.disabled = false;
}

function jumpToQuestionCard(qIndex) {
    const targetCard = document.getElementById(`preview_q_${qIndex}`);
    if (targetCard) {
        targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        targetCard.classList.remove('ai-target-highlight');
        void targetCard.offsetWidth; // Kích hoạt reflow
        targetCard.classList.add('ai-target-highlight');
        setTimeout(() => {
            targetCard.classList.remove('ai-target-highlight');
        }, 3600);
    }
    // Đồng bộ cuộn Editor
    scrollToQuestionInEditor(qIndex);
}

function applyAllAISuggestions() {
    if (!window.activeAIFeedbacks || Object.keys(window.activeAIFeedbacks).length === 0) {
        alert("Không có đề xuất sửa đổi nào cần áp dụng.");
        return;
    }

    const count = Object.keys(window.activeAIFeedbacks).length;
    if (!confirm(`Bạn có chắc muốn tự động sửa toàn bộ ${count} câu lỗi theo đề xuất của AI?`)) {
        return;
    }

    for (let qIndexStr in window.activeAIFeedbacks) {
        const qIndex = parseInt(qIndexStr);
        const aiData = window.activeAIFeedbacks[qIndex];
        if (aiData && currentData[qIndex]) {
            const corrected = aiData.corrected_data;
            const origGroup = currentData[qIndex].group_title;
            currentData[qIndex] = {
                ...corrected,
                group_title: corrected.group_title !== undefined ? corrected.group_title : origGroup
            };
        }
    }

    window.activeAIFeedbacks = {};

    const codeEditor = document.getElementById('codeEditor');
    if (codeEditor) {
        codeEditor.value = dataToEditorText(currentData);
        updateSyntaxHighlight();
    }

    renderPreviewAll();

    const btnApplyAll = document.getElementById('btnApplyAllAI');
    if (btnApplyAll) btnApplyAll.style.display = 'none';

    document.getElementById('aiFeedbackStats').innerHTML = `
        <div style="text-align: center; padding: 20px 10px;">
            <div style="font-size: 2.5rem; margin-bottom: 8px;">✨</div>
            <h3 style="margin: 0; color: #9333ea;">Đã tự động sửa thành công tất cả ${count} câu hỏi!</h3>
            <p style="margin: 4px 0 0 0; color: #64748b;">Dữ liệu đề thi và trình soạn thảo Code đã được cập nhật hoàn tất.</p>
        </div>
    `;
    document.getElementById('aiFeedbackContent').innerHTML = '';
}

function applyAISuggestion(question_index) {
    const aiData = window.activeAIFeedbacks[question_index];
    if (!aiData) return;
    
    const corrected_data = aiData.corrected_data;
    if (currentData[question_index]) {
        const originalGroupTitle = currentData[question_index].group_title;

        currentData[question_index] = {
            ...corrected_data,
            group_title: corrected_data.group_title !== undefined ? corrected_data.group_title : originalGroupTitle
        };

        delete window.activeAIFeedbacks[question_index];

        // Xóa khỏi danh sách tóm tắt ở trên
        const summaryItem = document.getElementById(`ai_summary_item_${question_index}`);
        if (summaryItem) summaryItem.remove();

        const codeEditor = document.getElementById('codeEditor');
        if (codeEditor) {
            codeEditor.value = dataToEditorText(currentData);
            updateSyntaxHighlight();
        }

        renderPreviewAll();

        const previewQuestion = document.getElementById(`preview_q_${question_index}`);
        if (previewQuestion) {
            previewQuestion.scrollIntoView({ behavior: 'smooth', block: 'center' });
            previewQuestion.style.transition = 'background-color 1s ease';
            previewQuestion.style.backgroundColor = '#d1fae5'; // Nháy màu xanh lá cây
            setTimeout(() => {
                previewQuestion.style.backgroundColor = '';
            }, 2000);
        }
        
        if (Object.keys(window.activeAIFeedbacks).length === 0) {
            document.getElementById('aiFeedbackBox').style.display = 'none';
        }
    } else {
        alert(`Lỗi: Không tìm thấy câu hỏi với chỉ số ${question_index}.`);
    }
}

function dismissAISuggestion(question_index) {
    delete window.activeAIFeedbacks[question_index];
    const summaryItem = document.getElementById(`ai_summary_item_${question_index}`);
    if (summaryItem) summaryItem.remove();
    
    renderPreviewAll();
    if (Object.keys(window.activeAIFeedbacks).length === 0) {
        document.getElementById('aiFeedbackBox').style.display = 'none';
    }
}

function renderData() {
    const container = document.getElementById('quiz-container');
    container.innerHTML = '';
    if (currentData.length === 0) { container.innerHTML = "<div class='card'>Không tìm thấy câu hỏi nào. Vui lòng kiểm tra lại định dạng file Word.</div>"; return; }
    
    document.getElementById('score-board').style.display = 'none';
    
    // Mở rộng Container khi ở chế độ chỉnh sửa
    const mainAppContainer = document.getElementById('mainAppContainer');
    if (currentMode === 'edit') {
        mainAppContainer.classList.add('wide-container');
    } else {
        mainAppContainer.classList.remove('wide-container');
    }

    if (currentMode === 'practice') {
        renderPracticeQuestion();
        return;
    }

    if (currentMode === 'edit') {
        container.innerHTML = `
            <div class="split-layout">
                <div class="preview-pane" id="preview-pane" style="padding: 0;">
                    <div style="background: #f8fafc; padding: 15px 20px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #e2e8f0; position: sticky; top: 0; z-index: 10; display: flex; justify-content: space-between; align-items: center;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span style="font-size: 1.3rem;">👁️</span> XEM TRƯỚC (GIAO DIỆN HỌC SINH)
                        </div>
                    </div>
                    <div id="preview-content" style="padding: 20px;"></div>
                </div>
                <div class="editor-pane" id="editor-pane" style="display: flex; flex-direction: column; padding: 0; background: #ffffff; overflow: hidden; border: 1px solid #e2e8f0;">
                    <div style="background: #f8fafc; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 10; border-bottom: 1px solid #e2e8f0;">
                        <div style="font-weight: 700; color: #0f172a; display: flex; align-items: center; gap: 8px;">
                            <span style="font-size: 1.3rem;">💻</span> HOCNHANHTN CODE EDITOR
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button style="padding: 6px 14px; font-size: 0.85rem; font-weight: 600; background: #0e639c; border: none; color: white; border-radius: 4px; cursor: pointer; transition: background 0.2s;" onmouseover="this.style.background='#1177bb'" onmouseout="this.style.background='#0e639c'" onclick="insertTextToEditor('\\n\\nCâu mới: \\nA. \\nB. \\nC. \\nD. ')">➕ Thêm Câu hỏi</button>
                        </div>
                    </div>
                    <div style="background: #f1f5f9; padding: 10px 20px; font-size: 0.9rem; color: #334155; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; gap: 8px;">
                        <span>💡 <b>Mẹo:</b> Gõ <code>Câu</code> và nhấn <b>Tab</b> để tạo nhanh khung câu hỏi. Click câu hỏi bên trái để tự động cuộn đến đoạn Code tương ứng.</span>
                    </div>
                    <div style="flex-grow: 1; position: relative; background: #ffffff;">
                        <style>
                            .editor-font {
                                font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, Courier, monospace;
                                font-size: 15px;
                                line-height: 1.8;
                                padding: 20px 20px 60px 20px;
                                box-sizing: border-box;
                                white-space: pre-wrap;
                                word-wrap: break-word;
                                margin: 0;
                                border: none;
                            }
                            #codeHighlight {
                                position: absolute;
                                top: 0; left: 0; right: 0; bottom: 0;
                                color: #333333;
                                overflow: hidden;
                                pointer-events: none;
                            }
                            #codeEditor {
                                position: absolute;
                                top: 0; left: 0; right: 0; bottom: 0;
                                background: transparent;
                                color: transparent;
                                caret-color: #000000;
                                resize: none;
                                outline: none;
                                overflow-y: auto;
                            }
                        #codeEditor::selection { background: rgba(0, 120, 215, 0.25); color: transparent; }
                            #codeEditor::-webkit-scrollbar { width: 14px; }
                            #codeEditor::-webkit-scrollbar-track { background: #f8fafc; }
                            #codeEditor::-webkit-scrollbar-thumb { background: #cbd5e1; border: 4px solid #f8fafc; border-radius: 8px; }
                            #codeEditor::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
                            
                            /* Syntax Colors (Chuẩn VS Code Light Theme) */
                            .hl-question { color: #0000ff; font-weight: bold; }
                            .hl-option { color: #af00db; font-weight: bold; }
                            .hl-correct { color: #059669; font-weight: bold; }
                            .hl-image { color: #a31515; }
                            .hl-math { color: #267f99; }
                            .hl-group { color: #795e26; font-weight: bold; }
                            .hl-html { color: #808080; }
                        </style>
                        <div id="codeHighlight" class="editor-font"></div>
                        <textarea id="codeEditor" class="editor-font" spellcheck="false"></textarea>
                    </div>
                </div>
            </div>
        `;
        const previewContent = document.getElementById('preview-content');
        const codeEditor = document.getElementById('codeEditor');

        codeEditor.value = dataToEditorText(currentData);
        updateSyntaxHighlight();
        renderPreviewAll();

        let editTimeout;
        codeEditor.addEventListener('input', function() {
            clearTimeout(editTimeout);
            editTimeout = setTimeout(() => {
                updateSyntaxHighlight(); // Đưa vào timeout để chống lag khi gõ nhanh (Debounce)
                currentData = parseEditorText(this.value);
                renderPreviewAll();
            }, 300);
        });
        
        codeEditor.addEventListener('scroll', function() {
            const codeHighlight = document.getElementById('codeHighlight');
            if (codeHighlight) {
                codeHighlight.scrollTop = this.scrollTop;
                codeHighlight.scrollLeft = this.scrollLeft;
            }
        });
        
        // TÍNH NĂNG AUTO-COMPLETE BẰNG PHÍM TAB
        codeEditor.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault(); // Chặn hành vi chuyển tab mặc định của trình duyệt
                const start = this.selectionStart;
                const end = this.selectionEnd;
                
                if (start === end) {
                    const textBefore = this.value.substring(0, start);
                    // Bắt từ khóa "cau" hoặc "câu" ở cuối đoạn text (trước con trỏ)
                    const match = textBefore.match(/(?:^|\n)\s*(cau|câu)$/i);
                    
                    if (match) {
                        // Tự động tính số thứ tự câu tiếp theo
                        const qCount = (this.value.match(/^(?:Câu|Bài|Question|Q)\s*\d+/gim) || []).length + 1;
                        const snippet = `Câu ${qCount}: \nA. \nB. \nC. \nD. `;
                        const replaceStart = start - match[1].length;
                        
                        this.value = this.value.substring(0, replaceStart) + snippet + this.value.substring(end);
                        
                        // Đặt con trỏ chuột ngay sau chữ "Câu X: "
                        const newCursorPos = replaceStart + `Câu ${qCount}: `.length;
                        this.selectionStart = this.selectionEnd = newCursorPos;
                        
                        updateSyntaxHighlight();
                        currentData = parseEditorText(this.value);
                        renderPreviewAll();
                        return; // Kết thúc sớm nếu đã Auto-complete
                    }
                }
                
                // Nếu không gõ "Câu", thực hiện thụt lề (indent) 4 khoảng trắng như VS Code
                this.value = this.value.substring(0, start) + "    " + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 4;
                updateSyntaxHighlight();
            }
        });
    } else {
        // TỐI ƯU HIỆU SUẤT RENDER: Gộp thành 1 chuỗi lớn thay vì appendChild liên tục
        let htmlBuilder = "";
        currentData.forEach((q, qIndex) => {
            let groupTitleHtml = q.group_title ? `<div style="background: #fef9c3; padding: 8px 12px; border-radius: 8px; margin-bottom: 10px; font-size: 0.9rem; font-weight: 600; color: #854d0e;">${q.group_title.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>` : '';
            let boxHtml = `<div class="card question-box" id="question_box_${qIndex}">`;
            boxHtml += `${groupTitleHtml}<div class="question-title">Câu ${qIndex + 1}: ${q.question.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>`;
            q.options.forEach((opt, oIndex) => {
                let char = opt.match(/^[A-F]/i) ? opt.match(/^[A-F]/i)[0].toUpperCase() : String.fromCharCode(65 + oIndex);
                let isChecked = quizProgress && quizProgress.answers && quizProgress.answers[qIndex] === opt;
                boxHtml += `
                    <label class="option-practice ${isChecked ? 'selected' : ''}" id="exam_opt_${qIndex}_${oIndex}">
                    <input type="radio" name="exam_${qIndex}" value="${escapeHtml(opt)}" onchange="selectExamOption(${qIndex}, ${oIndex})" ${isChecked ? 'checked' : ''}>
                        <span class="opt-badge">${char}</span>
                        <span class="opt-text">${opt.replace(/^[A-F][\.\:\)]\s*/i, '')}</span>
                    </label>`;
            });
            boxHtml += `</div>`;
            htmlBuilder += boxHtml;
        });
        container.innerHTML = htmlBuilder;
    }
    document.getElementById('aiCustomPrompt').style.display = currentMode === 'edit' ? 'block' : 'none';
    document.getElementById('btnAICheck').style.display = currentMode === 'edit' ? 'block' : 'none';
    if (currentMode !== 'edit') document.getElementById('aiFeedbackBox').style.display = 'none';
    document.getElementById('submitBtn').style.display = currentMode === 'exam' ? 'block' : 'none';
    renderMath();
}

function renderPracticeQuestion() {
    const container = document.getElementById('quiz-container');
    container.innerHTML = '';
    
    if (currentQuestionIndex >= currentData.length) {
        document.body.classList.add('quiz-completed'); // Mở khóa thanh cuộn toàn trang
        document.getElementById('score-board').style.display = 'block';
        document.getElementById('score-board').innerHTML = `Tiến trình hoàn tất! Bạn đúng <span style="color: var(--primary); font-size: 1.8rem;">${practiceScore}</span> / ${currentData.length} câu. 🎉<br>
            <div style="display: flex; justify-content: center; gap: 10px; flex-wrap: wrap; margin-top: 20px;">
                <button class="btn-outline" onclick="showPracticeReview()" style="background: white; margin: 0;">🔍 Xem chi tiết bài làm</button>
                <button class="btn-primary" onclick="restartPractice()" style="margin: 0;">🔄 Luyện tập lại vòng mới</button>
            </div>`;
        
        if (isStudentMode && studentName && !quizProgress.completed) {
            let timeElapsed = startTime > 0 ? Math.floor((Date.now() - startTime) / 1000) : 0;
            
            quizProgress.completed = true;
            if (!quizProgress.history) quizProgress.history = [];
            quizProgress.history.push({
                score: practiceScore,
                total: currentData.length,
                timeElapsed: timeElapsed,
                date: new Date().toLocaleString('vi-VN'),
                mode: 'Luyện tập'
            });
            saveProgressToLocal();
            submitScoreToServer(practiceScore, currentData.length, timeElapsed);
        }
        return;
    }

    practiceAnswered = false;
    const q = currentData[currentQuestionIndex];
    const box = document.createElement('div');
    box.className = 'card question-box';
    
    let groupTitleHtml = q.group_title ? `<div style="background: #fef9c3; padding: 8px 12px; border-radius: 8px; margin-bottom: 10px; font-size: 0.9rem; font-weight: 600; color: #854d0e;">${q.group_title.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>` : '';
    box.innerHTML += `${groupTitleHtml}<div class="question-title">Câu ${currentQuestionIndex + 1} / ${currentData.length}: ${q.question.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>`;
    
    q.options.forEach((opt, oIndex) => {
        let char = opt.match(/^[A-F]/i) ? opt.match(/^[A-F]/i)[0].toUpperCase() : String.fromCharCode(65 + oIndex);
        box.innerHTML += `
            <label class="option-practice" id="pract_opt_${oIndex}">
                <input type="radio" name="pract_radio" onclick="checkPracticeAnswer(${oIndex})">
                <span class="opt-badge">${char}</span>
                <span class="opt-text">${opt.replace(/^[A-F][\.\:\)]\s*/i, '')}</span>
            </label>`;
    });
    
    box.innerHTML += `<div id="pract_feedback" style="margin-top:20px; font-weight:600; font-size:1.1rem;"></div>`;
    
    container.appendChild(box);
    
    // Đưa nút ra khỏi khung câu hỏi, đẩy xuống dưới 1 chút và dạt sang phải
    const btnWrapper = document.createElement('div');
    btnWrapper.style.textAlign = 'right';
    btnWrapper.style.marginTop = '10px';
    btnWrapper.style.paddingBottom = '30px'; // Thêm khoảng đệm cho riêng nút bấm
    btnWrapper.innerHTML = `<button id="nextBtn" class="btn-primary" style="display:none; padding: 10px 24px; border-radius: 8px; font-weight: 600; font-size: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.15);" onclick="nextPracticeQuestion()">Câu tiếp ➔</button>`;
    container.appendChild(btnWrapper);
    renderMath();
}

function selectExamOption(qIndex, oIndex) {
    currentData[qIndex].options.forEach((_, idx) => {
        const lbl = document.getElementById(`exam_opt_${qIndex}_${idx}`);
        if (lbl) lbl.classList.remove('selected');
    });
    const selectedLbl = document.getElementById(`exam_opt_${qIndex}_${oIndex}`);
    if (selectedLbl) selectedLbl.classList.add('selected');
    
    if (isStudentMode) {
        if (!quizProgress.answers) quizProgress.answers = {};
        quizProgress.answers[qIndex] = currentData[qIndex].options[oIndex];
        saveProgressToLocal();
    }
}

function checkPracticeAnswer(oIndex) {
    if (practiceAnswered) return;
    practiceAnswered = true;
    
    const q = currentData[currentQuestionIndex];
    q.user_answer_practice = q.options[oIndex]; // Lưu lại đáp án của học sinh để dùng cho phần xem lại
    const isCorrect = q.options[oIndex] === q.correct_answer;
    
    if (isCorrect) practiceScore++;
    
    q.options.forEach((opt, idx) => {
        const lbl = document.getElementById(`pract_opt_${idx}`);
        lbl.querySelector('input').disabled = true;
        
        if (idx === oIndex) lbl.classList.add('selected'); // Đánh dấu khối đang chọn
        
        if (opt === q.correct_answer) lbl.classList.add('correct');
        else if (idx === oIndex && !isCorrect) lbl.classList.add('incorrect');
    });
    
    const feedback = document.getElementById('pract_feedback');
    let correctAnswerDisplay = q.correct_answer ? q.correct_answer.replace(/^[A-D][\.\:\)]\s*/i, '') : "Chưa xác định";
    feedback.innerHTML = isCorrect ? `<span style="color:var(--success);">✅ Trả lời chính xác!</span>` : `<span style="color:var(--danger);">❌ Sai rồi! Đáp án đúng là: ${correctAnswerDisplay}</span>`;
    
    document.getElementById('nextBtn').style.display = 'inline-block';
    if (currentQuestionIndex === currentData.length - 1) document.getElementById('nextBtn').innerText = 'Xem kết quả tổng kết';
    
    // Tự động cuộn trượt màn hình xuống nút "Câu tiếp" mượt mà
    setTimeout(() => {
        document.getElementById('nextBtn').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 100);
}

function nextPracticeQuestion() {
    currentQuestionIndex++;
    renderPracticeQuestion();
}

function showPracticeReview() {
    const container = document.getElementById('quiz-container');
    container.innerHTML = '';
    
    currentData.forEach((q, qIndex) => {
        const box = document.createElement('div');
        box.className = 'card question-box';
        
        let groupTitleHtml = q.group_title ? `<div style="background: #fef9c3; padding: 8px 12px; border-radius: 8px; margin-bottom: 10px; font-size: 0.9rem; font-weight: 600; color: #854d0e;">${q.group_title.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>` : '';
        box.innerHTML += `${groupTitleHtml}<div class="question-title">Câu ${qIndex + 1}: ${q.question.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>`;
        
        q.options.forEach((opt, oIndex) => {
            let char = opt.match(/^[A-F]/i) ? opt.match(/^[A-F]/i)[0].toUpperCase() : String.fromCharCode(65 + oIndex);
            
            let extraClass = '';
            let isSelected = opt === q.user_answer_practice;
            if (isSelected) extraClass += ' selected ';
            if (opt === q.correct_answer) {
                extraClass += ' correct ';
            } else if (isSelected && opt !== q.correct_answer) {
                extraClass += ' incorrect ';
            }
            
            box.innerHTML += `
                <label class="option-practice ${extraClass.trim()}" style="cursor: default;">
                    <input type="radio" disabled ${isSelected ? 'checked' : ''}>
                    <span class="opt-badge">${char}</span>
                    <span class="opt-text">${opt.replace(/^[A-F][\.\:\)]\s*/i, '')}</span>
                </label>`;
        });
        container.appendChild(box);
    });
    renderMath();
}

function shuffleQuiz(noRender = false) {
    for (let i = currentData.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [currentData[i], currentData[j]] = [currentData[j], currentData[i]];
    }
    currentData.forEach(q => {
        // 1. Chuẩn hóa lại số thứ tự câu hỏi (Xóa "Câu X:" cũ nếu có)
        q.question = q.question.replace(/^(?:(?:Câu|Bài|Question|Q)\s*\d+\s*[\.\:\-\)]|\d+\s*[\.\:\)])\s*/i, '');
        
        // 2. Trộn ngẫu nhiên các đáp án
        for (let i = q.options.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [q.options[i], q.options[j]] = [q.options[j], q.options[i]];
        }
        
        // 3. Đánh lại nhãn A, B, C, D và cập nhật đáp án đúng theo vị trí mới
        let newCorrect = null;
        q.options = q.options.map((opt, oIndex) => {
            let cleanOpt = opt.replace(/^[A-F][\.\:\)]\s*/i, '');
            let newOpt = String.fromCharCode(65 + oIndex) + ". " + cleanOpt;
            if (opt === q.correct_answer) newCorrect = newOpt;
            return newOpt;
        });
        if (newCorrect) q.correct_answer = newCorrect;
    });
    currentQuestionIndex = 0;
    practiceScore = 0;
    if (!noRender) renderData();
}

function switchMode(mode) {
    currentMode = mode;
    document.getElementById('btnEdit').className = mode === 'edit' ? 'btn-outline active' : 'btn-outline';
    document.getElementById('btnPractice').className = mode === 'practice' ? 'btn-outline active' : 'btn-outline';
    document.getElementById('btnExam').className = mode === 'exam' ? 'btn-outline active' : 'btn-outline';
    document.getElementById('btnShuffle').style.display = mode === 'edit' ? 'none' : 'inline-block';
    
    // Ẩn bảng xếp hạng và Timer dọn dẹp khi chuyển chế độ hoặc làm lại bài
    const lb = document.getElementById('leaderboard');
    if (lb) lb.style.display = 'none';
    clearInterval(timerInterval);
    const timerDisplay = document.getElementById('timerDisplay');
    if (timerDisplay) timerDisplay.style.display = 'none';

    document.body.classList.remove('quiz-completed');
    if (isStudentMode) {
        startTime = Date.now(); // Bắt đầu bấm giờ
        quizProgress.completed = false; // Sẵn sàng ghi nhận cho vòng mới
    }
    currentQuestionIndex = 0;
    practiceScore = 0;
    renderData();
}

function dataToEditorText(data) {
    let text = "";
    data.forEach((q, i) => {
        if (q.group_title && (i === 0 || q.group_title !== data[i-1].group_title)) {
            text += `${q.group_title.replace(/<br>/gi, '\n')}\n`;
        }
        let qClean = q.question.replace(/^(?:(?:Câu|Bài|Question|Q)\s*\d+\s*[\.\:\-\)]|\d+\s*[\.\:\)])\s*/i, '').replace(/<br>/gi, '\n');
        text += `Câu ${i + 1}: ${qClean}\n`;
        
        q.options.forEach((opt) => {
            let isCorrect = (q.correct_answer === opt);
            let optText = opt.replace(/<br>/gi, '\n');
            if (isCorrect) {
                optText = optText.replace(/^([A-F])([\.\:\)])/i, '*$1$2'); // Đánh dấu sao cho đáp án đúng
            }
            text += `${optText}\n`;
        });
        text += "\n";
    });
    
    text = text.trim();
    
    // Xóa bộ nhớ cũ mỗi lần generate lại code cho editor
    globalEditorImageStorage = {};
    globalEditorImageCounter = 0;
    
    // Tìm toàn bộ thẻ <img> (Base64 hoặc URL /api/images/...) và thay bằng [HÌNH_ẢNH_X]
    const imgRegex = /<img[^>]+src=['"][^'"]+['"][^>]*\/?>/gi;
    text = text.replace(imgRegex, (match) => {
        let existingKey = Object.keys(globalEditorImageStorage).find(key => globalEditorImageStorage[key] === match);
        if (existingKey) return existingKey;
        
        globalEditorImageCounter++;
        let placeholder = `[HÌNH_ẢNH_${globalEditorImageCounter}]`;
        globalEditorImageStorage[placeholder] = match;
        return placeholder;
    });
    
    return text;
}

function parseEditorText(text) {
    // Trả lại mã Base64 thật cho các thẻ [HÌNH_ẢNH_X] trước khi bóc tách
    let restoredText = text;
    for (let key in globalEditorImageStorage) {
        restoredText = restoredText.split(key).join(globalEditorImageStorage[key]);
    }
    
    const data = [];
    let currentQ = null;
    const lines = restoredText.split('\n');
    let sharedContext = "";

    const qRegex = /^\s*(Câu|Bài|Question|Q)\s*\d+[\.\:\-\)]/i;
    const optRegex = /^\s*(\*?\s*[A-F])[\.\:\)]/i;
    const groupRegex = /^\s*(PHẦN|PART|CHƯƠNG|BÀI TẬP|I{1,3}\.|IV\.|V\.|VI{0,3}\.)\b/i;

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmed = line.trim();
        
        if (trimmed === '') continue;

        if (qRegex.test(line)) {
            if (currentQ) data.push(currentQ);
            let qText = line.replace(qRegex, '').trim();
            currentQ = { group_title: sharedContext.trim(), question: qText, options: [], correct_answer: null };
            sharedContext = ""; 
        } else if (optRegex.test(line)) {
            const match = line.match(optRegex);
            const charRaw = match[1].trim().toUpperCase();
            const isCorrect = charRaw.includes('*');
            const char = charRaw.replace('*', '').trim();
            let optContent = line.replace(optRegex, '').trim();
            
            const fullOpt = `${char}. ${optContent}`;
            if (currentQ) {
                currentQ.options.push(fullOpt);
                if (isCorrect) currentQ.correct_answer = fullOpt;
            }
        } else if (groupRegex.test(line)) {
            sharedContext += (sharedContext ? "<br>" : "") + line;
        } else {
            if (currentQ && currentQ.options.length > 0) {
                currentQ.options[currentQ.options.length - 1] += "<br>" + line;
            } else if (currentQ) {
                currentQ.question += (currentQ.question ? "<br>" : "") + line;
            } else {
                sharedContext += (sharedContext ? "<br>" : "") + line;
            }
        }
    }
    if (currentQ) data.push(currentQ);
    
    // Quét lại nếu chưa có đáp án đúng thì lấy mặc định đáp án A
    data.forEach(q => {
        if (!q.correct_answer && q.options.length > 0) { q.correct_answer = q.options[0]; }
    });
    return data;
}

function renderPreviewAll() {
    const previewContent = document.getElementById('preview-content');
    if (!previewContent) return;
    previewContent.innerHTML = '';
    
    currentData.forEach((q, qIndex) => {
        const prevBox = document.createElement('div');
        prevBox.className = 'question-box';
        prevBox.id = `preview_q_${qIndex}`;
        prevBox.style.marginBottom = '24px';
        prevBox.style.cursor = 'pointer';
        prevBox.title = 'Nhấn để nhảy tới mã Code của câu này';
        prevBox.onclick = () => scrollToQuestionInEditor(qIndex);
        
        let hasError = window.activeAIFeedbacks && window.activeAIFeedbacks[qIndex];
        if (hasError) {
            prevBox.style.borderColor = '#c084fc';
            prevBox.style.boxShadow = '0 4px 12px rgba(147, 51, 234, 0.08)';
        }

        let html = "";
        let groupTitleHtml = q.group_title ? `<div style="background: #fef9c3; padding: 8px 12px; border-radius: 8px; margin-bottom: 10px; font-size: 0.9rem; font-weight: 600; color: #854d0e;">${q.group_title.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>` : '';
        let qClean = q.question.replace(/^(?:(?:Câu|Bài|Question|Q)\s*\d+\s*[\.\:\-\)]|\d+\s*[\.\:\)])\s*/i, '');
        
        html += `${groupTitleHtml}<div class="question-title">Câu ${qIndex + 1}: ${qClean.replace(/(?:\r\n|\r|\n|\\n)/g, '<br>')}</div>`;
        q.options.forEach((opt, oIndex) => {
            let isCorrect = q.correct_answer === opt;
            html += `<label class="option-practice ${isCorrect ? 'correct selected' : ''}" style="cursor: default;">
                        <input type="radio" disabled ${isCorrect ? 'checked' : ''}>
                        <span class="opt-badge">${opt.match(/^[A-F]/i) ? opt.match(/^[A-F]/i)[0].toUpperCase() : String.fromCharCode(65 + oIndex)}</span>
                        <span class="opt-text">${opt.replace(/^[A-F][\.\:\)]\s*/i, '')}</span>
                    </label>`;
        });
        prevBox.innerHTML = html;
        
        // KIỂM TRA VÀ CHÈN UI GỢI Ý CỦA AI VÀO NGAY DƯỚI CÂU HỎI
        if (hasError) {
            const aiData = window.activeAIFeedbacks[qIndex];
            const catClass = aiData.category === 'knowledge' ? 'ai-cat-knowledge' :
                             (aiData.category === 'answer' ? 'ai-cat-answer' :
                             (aiData.category === 'grammar_typo' ? 'ai-cat-grammar' : 'ai-cat-format'));

            const aiDiv = document.createElement('div');
            aiDiv.style.cssText = 'margin-top: 15px; padding: 14px; background: #faf5ff; border: 1.5px solid #d8b4fe; border-radius: 10px; cursor: default;';
            aiDiv.onclick = (e) => e.stopPropagation(); // Ngăn sự kiện cuộn editor
            
            let corrected = aiData.corrected_data || {};
            let correctedAnswerText = corrected.correct_answer || '';
            let explainText = corrected.explain ? `<div style="margin-top: 6px; font-size: 0.88rem; color: #475569;"><b>💡 Giải thích:</b> ${corrected.explain}</div>` : '';

            aiDiv.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 1.2rem;">🤖</span>
                        <strong style="color: #9333ea;">AI Phát hiện vấn đề:</strong>
                        <span class="ai-cat-chip ${catClass}" style="padding: 2px 8px; font-size: 0.75rem;">${aiData.category_name || 'Cần sửa'}</span>
                    </div>
                </div>
                <div style="color: #dc2626; font-size: 0.92rem; font-weight: 600; margin-bottom: 8px;">
                    ${aiData.reason}
                </div>
                ${correctedAnswerText ? `<div style="font-size: 0.88rem; background: #f0fdf4; padding: 6px 10px; border-radius: 6px; border: 1px solid #bbf7d0; color: #166534; margin-bottom: 8px;">
                    <b>✨ Đề xuất đáp án đúng:</b> ${escapeHtml(correctedAnswerText)}
                </div>` : ''}
                ${explainText}
                <div style="margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap;">
                    <button class="btn-primary" style="padding: 6px 14px; font-size: 0.85rem; background: #9333ea; border: none; border-radius: 6px;" onclick="applyAISuggestion(${qIndex})">✨ Tự động sửa câu này</button>
                    <button class="btn-outline" style="padding: 6px 12px; font-size: 0.85rem; border-color: #d8b4fe; color: #9333ea; border-radius: 6px;" onclick="dismissAISuggestion(${qIndex})">❌ Bỏ qua</button>
                </div>
            `;
            prevBox.appendChild(aiDiv);
        }
        
        previewContent.appendChild(prevBox);
    });

    if (window.MathJax && typeof window.MathJax.typesetPromise === 'function') {
        MathJax.typesetPromise([previewContent]).catch((err) => console.log('MathJax error:', err));
    }
}

function scrollToQuestionInEditor(qIndex) {
    const editor = document.getElementById('codeEditor');
    if (!editor) return;
    
    const text = editor.value;
    const lines = text.split('\n');
    const qRegex = /^\s*(Câu|Bài|Question|Q)\s*\d+[\.\:\-\)]/i;
    
    let currentQCount = -1;
    let charOffset = 0;
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.trim() !== '') {
            if (qRegex.test(line)) {
                currentQCount++;
                if (currentQCount === qIndex) {
                    editor.focus();
                    editor.setSelectionRange(charOffset, charOffset + line.length);
                    
                    // Thuật toán cuộn mượt: Tính tọa độ Y tuyệt đối dựa trên tỷ lệ ký tự
                    // Cách này miễn nhiễm với lỗi Word-wrap và cực kỳ ổn định trên mọi trình duyệt
                    const scrollRatio = charOffset / text.length;
                    const targetScroll = editor.scrollHeight * scrollRatio;
                    
                    // Đẩy thanh cuộn đến đúng mục tiêu, trừ lùi 56px (~1.5cm) để tạo khoảng thở ở mép trên
                    editor.scrollTop = targetScroll - 56;
                    return;
                }
            }
        }
        charOffset += line.length + 1; // +1 là đếm khoảng trắng của ký tự xuống dòng (\n)
    }
}

function startTimer(minutes) {
    clearInterval(timerInterval);
    let timeRemaining = minutes * 60;
    
    if (isStudentMode && quizProgress && quizProgress.timeRemaining !== undefined && quizProgress.timeRemaining !== null && !quizProgress.completed) {
        timeRemaining = quizProgress.timeRemaining; // Phục hồi đồng hồ
    }
    const timerDisplay = document.getElementById('timerDisplay');
    timerDisplay.style.display = 'block';
    
    function updateDisplay() {
        const m = Math.floor(timeRemaining / 60).toString().padStart(2, '0');
        const s = (timeRemaining % 60).toString().padStart(2, '0');
        timerDisplay.innerText = `⏳ ${m}:${s}`;
        if (timeRemaining <= 60) {
            timerDisplay.style.animation = "pulse-red 1s infinite";
        }
    }
    updateDisplay();
    
    timerInterval = setInterval(() => {
        timeRemaining--;
        if (isStudentMode) {
            quizProgress.timeRemaining = timeRemaining;
            if (timeRemaining % 5 === 0) saveProgressToLocal(); // Cứ 5 giây lưu đồng hồ 1 lần
        }
        if (timeRemaining < 0) {
            clearInterval(timerInterval);
            alert("⏳ Đã hết thời gian làm bài! Hệ thống tự động nộp bài.");
            submitExam();
            return;
        }
        updateDisplay();
    }, 1000);
}

function formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m} phút ${s} giây`;
}

async function submitScoreToServer(score, total, time) {
    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('quiz_id') || urlParams.get('id');
    if (!quizId) return;
    try {
        await fetch(`${API_BASE_URL}/api/submit_score`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ quiz_id: quizId, student_name: studentName, score: score, total_questions: total, time_elapsed: time })
        });
        fetchLeaderboard(quizId);
    } catch(e) { console.log(e); }
}

async function fetchLeaderboard(quizId) {
    try {
        const response = await fetch(`${API_BASE_URL}/api/leaderboard/${quizId}`);
        const result = await response.json();
        if (result.status === 'success') {
            const lb = document.getElementById('leaderboard');
            const lbList = document.getElementById('leaderboardList');
            lb.style.display = 'block';
            
            let html = `<table style="width:100%; border-collapse: collapse; text-align:left; min-width: 500px;">
                <tr style="border-bottom: 2px solid var(--border); color: var(--text-muted);">
                    <th style="padding: 12px 10px;">Hạng</th>
                    <th style="padding: 12px 10px;">Họ Tên</th>
                    <th style="padding: 12px 10px;">Điểm</th>
                    <th style="padding: 12px 10px;">Thời gian</th>
                </tr>`;
            
            result.data.forEach((item, index) => {
                let rank = index + 1;
                let medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : rank;
                let isMe = item.student_name === studentName;
                html += `
                    <tr style="border-bottom: 1px solid var(--border); ${isMe ? 'background-color: #fef9c3; font-weight:bold;' : ''}">
                        <td style="padding: 12px 10px; font-size: 1.2rem;">${medal}</td>
                        <td style="padding: 12px 10px;">${item.student_name} ${isMe ? '<span style="color:var(--success); font-size:0.8rem;">(Bạn)</span>' : ''}</td>
                        <td style="padding: 12px 10px; color: var(--primary); font-weight: bold; font-size: 1.1rem;">${item.score} / ${currentData.length}</td>
                        <td style="padding: 12px 10px; color: var(--text-muted);">${formatTime(item.time_elapsed)}</td>
                    </tr>`;
            });
            html += `</table>`;
            lbList.innerHTML = html;
        }
    } catch(e) { console.log(e); }
}

async function submitExam(isReview = false) {
    clearInterval(timerInterval);
    const timerDisplay = document.getElementById('timerDisplay');
    if (timerDisplay) timerDisplay.style.display = 'none';
    
    let sessionTime = startTime > 0 ? Math.floor((Date.now() - startTime) / 1000) : 0;
    let totalTimeElapsed = isReview ? (quizProgress.timeElapsed || 0) : ((quizProgress.timeElapsed || 0) + sessionTime);
    let score = 0;
    
    // Thu thập câu trả lời của học sinh
    let userAnswers = {};
    currentData.forEach((q, qIndex) => {
        let userAnswer = null;
        if (isReview && quizProgress && quizProgress.answers) {
            userAnswer = quizProgress.answers[qIndex];
        } else {
            const selected = document.querySelector(`input[name="exam_${qIndex}"]:checked`);
            userAnswer = selected ? selected.value : null;
        }
        if (userAnswer) userAnswers[qIndex] = userAnswer;
    });

    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('quiz_id') || urlParams.get('id');
    let backendResults = null;
    let verifiedScore = null;

    // CHẤM ĐIỂM PHÍA SERVER (BẢO MẬT & CHỐNG HACK ĐIỂM F12)
    if (!isReview && quizId) {
        try {
            const res = await fetch(`${API_BASE_URL}/api/student/submit_exam`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    quiz_id: quizId,
                    student_name: studentName || 'Học sinh',
                    student_token: authToken || '',
                    answers: userAnswers,
                    time_elapsed: totalTimeElapsed
                })
            });
            const resData = await res.json();
            if (res.ok && resData.status === 'success') {
                verifiedScore = resData.score;
                backendResults = resData.results;
            }
        } catch(err) {
            console.warn("Lỗi kết nối server chấm điểm, sử dụng cơ chế nội bộ:", err);
        }
    }
    
    // Áp dụng kết quả xác thực từ Backend
    if (backendResults && Array.isArray(backendResults)) {
        score = verifiedScore;
        backendResults.forEach(item => {
            const qIndex = item.question_index;
            const q = currentData[qIndex];
            if (!q) return;
            
            q.correct_answer = item.correct_answer;
            q.explain = item.explain;
            const userAnswer = item.user_answer;
            
            q.options.forEach((opt, oIndex) => {
                const optEl = document.getElementById(`exam_opt_${qIndex}_${oIndex}`);
                if (optEl) {
                    optEl.classList.remove('correct', 'incorrect');
                    const inputEl = optEl.querySelector('input');
                    if (inputEl) inputEl.disabled = true;
                    
                    if (opt === item.correct_answer) {
                        optEl.classList.add('correct');
                    } else if (opt === userAnswer && !item.is_correct) {
                        optEl.classList.add('incorrect');
                    }
                }
            });
            
            // Hiển thị lời giải thích chi tiết dưới câu hỏi nếu có
            if (item.explain) {
                const qCard = document.getElementById(`exam_q_${qIndex}`) || (document.getElementById(`exam_opt_${qIndex}_0`) ? document.getElementById(`exam_opt_${qIndex}_0`).parentElement : null);
                if (qCard && !qCard.querySelector('.exam-explain-box')) {
                    const expDiv = document.createElement('div');
                    expDiv.className = 'exam-explain-box';
                    expDiv.style.cssText = 'margin-top: 12px; padding: 10px 14px; background: #f0fdf4; border-left: 4px solid #22c55e; border-radius: 6px; font-size: 0.95rem; color: #166534;';
                    expDiv.innerHTML = `<b>💡 Hướng dẫn giải:</b> ${item.explain}`;
                    qCard.appendChild(expDiv);
                }
            }
        });
    } else {
        // Fallback chế độ xem lại (Review) hoặc Offline
        currentData.forEach((q, qIndex) => {
            let userAnswer = userAnswers[qIndex];
            
            if (isReview && userAnswer) {
                const oIndex = q.options.indexOf(userAnswer);
                if(oIndex !== -1) {
                    const r = document.querySelector(`#exam_opt_${qIndex}_${oIndex} input`);
                    if(r) r.checked = true;
                    const lbl = document.getElementById(`exam_opt_${qIndex}_${oIndex}`);
                    if(lbl) lbl.classList.add('selected');
                }
            }
            
            q.options.forEach((opt, oIndex) => {
                const optEl = document.getElementById(`exam_opt_${qIndex}_${oIndex}`);
                if (optEl) {
                    optEl.classList.remove('correct', 'incorrect');
                    const inputEl = optEl.querySelector('input');
                    if (inputEl) inputEl.disabled = true;
                    
                    if (opt === q.correct_answer) {
                        optEl.classList.add('correct');
                    } else if (opt === userAnswer && userAnswer !== q.correct_answer) {
                        optEl.classList.add('incorrect');
                    }
                }
            });
            
            if (userAnswer === q.correct_answer) score++;
        });
    }
    
    document.getElementById('submitBtn').style.display = 'none';
    document.body.classList.add('quiz-completed');
    
    const scoreBoard = document.getElementById('score-board');
    scoreBoard.style.display = 'block';
    scoreBoard.innerHTML = `Kết quả thi: <span style="color: var(--primary); font-size: 1.8rem;">${score}</span> / ${currentData.length} câu chính xác! 🎉<br>
                            <span style="font-size: 1.1rem; color: var(--text-muted);">⏱ Thời gian: ${formatTime(totalTimeElapsed)}</span><br>
                            <div style="display: flex; justify-content: center; gap: 10px; flex-wrap: wrap; margin-top: 15px;">
                                <button class="btn-outline" style="margin: 0;" onclick="document.getElementById('quiz-container').scrollIntoView({behavior: 'smooth'})">👇 Xem chi tiết sai/đúng</button>
                                <button class="btn-primary" style="margin: 0;" onclick="restartExam()">🔄 Thi lại vòng mới</button>
                            </div>`;
    
    if (!isReview && isStudentMode && studentName) { 
        if (!quizProgress.answers) quizProgress.answers = {};
        Object.assign(quizProgress.answers, userAnswers);
        quizProgress.completed = true;
        quizProgress.score = score;
        quizProgress.timeElapsed = totalTimeElapsed;
        
        if (!quizProgress.history) quizProgress.history = [];
        quizProgress.history.push({
            score: score,
            total: currentData.length,
            timeElapsed: totalTimeElapsed,
            date: new Date().toLocaleString('vi-VN'),
            mode: 'Thi thử'
        });
        
        saveProgressToLocal();
        sendPing();
        if (quizId) fetchLeaderboard(quizId);
    }
    
    const quizContainer = document.getElementById('quiz-container');
    if (quizContainer) quizContainer.scrollTo({ top: 0, behavior: 'smooth' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
    renderMath();
}

function exitMinimalMode() {
    if (confirm("Bạn có muốn tạm dừng và thoát khỏi giao diện làm bài không? (Tiến trình của bạn vẫn được bảo lưu)")) {
        document.body.classList.remove('minimal-mode');
        document.body.classList.remove('quiz-completed');
        if (document.fullscreenElement) {
            document.exitFullscreen().catch(err => console.log(err));
        }
        window.location.reload(); // Tải lại trang để reset giao diện và đưa về màn hình Welcome
    }
}

// Hàm hỗ trợ chèn nhanh text vào khung Code Editor
function insertTextToEditor(text) {
    const editor = document.getElementById('codeEditor');
    if (!editor) return;
    
    const start = editor.selectionStart;
    const end = editor.selectionEnd;
    const val = editor.value;
    
    editor.value = val.substring(0, start) + text + val.substring(end);
    editor.selectionStart = editor.selectionEnd = start + text.length;
    editor.focus();
    
    updateSyntaxHighlight();
    currentData = parseEditorText(editor.value);
    renderPreviewAll();
}

// Hàm xử lý Highlight Code (Syntax Highlighting)
function updateSyntaxHighlight() {
    const codeEditor = document.getElementById('codeEditor');
    const codeHighlight = document.getElementById('codeHighlight');
    if (!codeEditor || !codeHighlight) return;
    
    let text = codeEditor.value;
    let escaped = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    
    // Đổi màu các keyword và pattern
    escaped = escaped.replace(/(\[HÌNH_ẢNH_\d+\])/g, '<span class="hl-image">$1</span>');
    escaped = escaped.replace(/(\\\([\s\S]*?\\\))/g, '<span class="hl-math">$1</span>');
    escaped = escaped.replace(/^(\s*)(Câu|Bài|Question|Q)(\s*\d+[\.\:\-\)])/gim, '$1<span class="hl-question">$2$3</span>');
    escaped = escaped.replace(/^(\s*)(\*\s*[A-F][\.\:\)])/gim, '$1<span class="hl-correct">$2</span>');
    escaped = escaped.replace(/^(\s*)([A-F][\.\:\)])/gim, '$1<span class="hl-option">$2</span>');
    escaped = escaped.replace(/^(\s*)(PHẦN|PART|CHƯƠNG|BÀI TẬP|I{1,3}\.|IV\.|V\.|VI{0,3}\.)(.*)$/gim, '$1<span class="hl-group">$2$3</span>');
    escaped = escaped.replace(/(&lt;\/?(b|i|u|sub|sup|MARK)&gt;)/gi, '<span class="hl-html">$1</span>');
    
    // Fix lỗi mất padding-bottom khi người dùng gõ Enter xuống dòng mới nhất
    if (escaped.endsWith('\n')) escaped += ' ';
    
    codeHighlight.innerHTML = escaped;
}